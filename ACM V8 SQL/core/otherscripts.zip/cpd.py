# core/cpd.py
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Dict
from utils.logger import Console


def _robust_z(x: np.ndarray) -> np.ndarray:
    if x.size == 0:
        return x
    med = np.median(x)
    mad = np.median(np.abs(x - med)) + 1e-9
    return (x - med) / (1.4826 * mad)


def _cusum(x: np.ndarray, k: float = 0.5, h: float = 5.0) -> np.ndarray:
    """
    Simple two-sided CUSUM on standardized series.
    Returns an "alarm score" (>=0), not just boolean.
    """
    if x.size == 0:
        return x
    gp = np.zeros_like(x, dtype=float)  # positive drift
    gn = np.zeros_like(x, dtype=float)  # negative drift
    alarm = np.zeros_like(x, dtype=float)

    for i in range(1, len(x)):
        gp[i] = max(0.0, gp[i - 1] + x[i] - k)
        gn[i] = max(0.0, gn[i - 1] - x[i] - k)
        alarm[i] = max(gp[i], gn[i])  # magnitude of excursion

    # Normalise alarm to [0..1+] by p95
    p95 = np.percentile(alarm, 95) if alarm.size else 1.0
    return np.clip(alarm / (p95 + 1e-9), 0.0, 10.0)


def detect(score_out: Dict[str, np.ndarray], cfg: Dict) -> Dict[str, np.ndarray]:
    """
    Change-point proxy using robust-z of a combined anomaly stream:
      s = z(pca_recon_err) + z(iforest_score) + 0.5*z(ar1_residual)
    Then apply CUSUM → cpd_score in ~[0..1+]; also output cpd_flag via threshold.
    """
    p = score_out.get("pca_recon_err", np.array([]))
    i = score_out.get("iforest_score", np.array([]))
    a = score_out.get("ar1_residual", np.array([]))
    if p.size == 0:
        return {"cpd_score": np.array([]), "cpd_flag": np.array([], dtype=int)}

    z = _robust_z(p) + _robust_z(i) + 0.5 * _robust_z(a)
    cpd_score = _cusum(z, k=0.5, h=5.0)

    # threshold (configurable later if needed)
    th = float(cfg.get("cpd", {}).get("threshold", 0.85))
    cpd_flag = (cpd_score >= th).astype(int)

    return {"cpd_score": cpd_score, "cpd_flag": cpd_flag}


def export(run_paths, cpd_out: Dict[str, np.ndarray]) -> None:
    """Write cpd.csv with cpd_score and cpd_flag."""
    out = pd.DataFrame(cpd_out)
    p = run_paths.run_dir / "cpd.csv"  # type: ignore
    out.to_csv(p, index=False)
    Console.ok(f"[EXPORT] Wrote {p}")
