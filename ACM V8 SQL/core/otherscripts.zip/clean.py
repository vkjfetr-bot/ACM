"""Cleaning utilities: NaN policy, interpolation limits, spike & flatline guards."""

from __future__ import annotations

from typing import Dict, Any, Tuple, List
import numpy as np
import pandas as pd


def _hampel_spike_mask(x: np.ndarray, k: float = 3.0) -> np.ndarray:
    """Return boolean mask of spikes using a Hampel-like rule on residuals."""
    if k is False or k is None or k <= 0:
        return np.zeros_like(x, dtype=bool)
    med = np.nanmedian(x)
    mad = np.nanmedian(np.abs(x - med))
    if not np.isfinite(mad) or mad == 0:
        return np.zeros_like(x, dtype=bool)
    z = np.abs(x - med) / (1.4826 * mad)  # robust z
    return z > k


def _flatline_mask(x: np.ndarray, window: int) -> np.ndarray:
    """Return boolean mask where a series is effectively flat over `window` samples."""
    if not window or window <= 1:
        return np.zeros_like(x, dtype=bool)
    # rolling std with minimum periods = window
    s = pd.Series(x)
    rstd = s.rolling(window, min_periods=window).std().to_numpy()
    return np.nan_to_num(rstd, nan=0.0) == 0.0


def clean_frame(df: pd.DataFrame, cfg: Dict[str, Any]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Apply column filtering, interpolation policy, spike/flatline detection.
    Returns cleaned df and an info dict with decisions for logging/report.
    """
    info: Dict[str, Any] = {"dropped_cols": [], "spike_cols": [], "flatline_cols": []}
    c = cfg.get("clean", {})
    dropna_thresh = float(c.get("dropna_thresh", 0.7))
    max_gap = int(c.get("max_gap", 5))
    spike_k = c.get("spike_hampel_k", 3.0)
    flat_win = int(c.get("flatline_window", 50))
    near_const_eps = float(c.get("near_const_var_eps", 1e-9))

    # 1) Drop columns with low non-null coverage
    nnr = df.notna().mean(axis=0)
    keep = nnr[nnr >= dropna_thresh].index.tolist()
    drop_cov = [col for col in df.columns if col not in keep]
    if drop_cov:
        df = df[keep]
        info["dropped_cols"].extend(drop_cov)

    # 2) Drop near-constant columns
    vari = df.var(axis=0, ddof=0)
    drop_const = vari.index[vari <= near_const_eps].tolist()
    if drop_const:
        df = df.drop(columns=drop_const, errors="ignore")
        info["dropped_cols"].extend(drop_const)

    # 3) Interpolate short gaps, leave long gaps as NaN (mask later)
    if max_gap and max_gap > 0:
        df = df.interpolate(limit=max_gap, limit_direction="both")

    # 4) Spike detection (mark; do not overwrite values here)
    if spike_k and spike_k > 0:
        for col in df.columns:
            mask = _hampel_spike_mask(df[col].to_numpy(dtype=float), float(spike_k))
            if mask.any():
                info["spike_cols"].append(col)

    # 5) Flatline detection (mark; can be used to downweight later)
    if flat_win and flat_win > 1:
        for col in df.columns:
            mask = _flatline_mask(df[col].to_numpy(dtype=float), flat_win)
            if mask.any():
                info["flatline_cols"].append(col)

    # 6) Final NaN policy: drop rows that are entirely NaN; keep partials
    df = df.dropna(how="all")

    return df, info
