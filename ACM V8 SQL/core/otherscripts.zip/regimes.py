# core/regimes.py
# Fast + memory-safe regime labeling with auto-k.
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
import json
import numpy as np
import pandas as pd
from pathlib import Path

import joblib
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ----------------------------
# Small helpers / sane defaults
# ----------------------------
def _cfg_get(cfg: Dict[str, Any], path: str, default: Any) -> Any:
    cur = cfg or {}
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur

def _as_f32(X) -> np.ndarray:
    return np.asarray(X, dtype=np.float32, order="C")

def _finite_impute_inplace(X: np.ndarray) -> np.ndarray:
    X = _as_f32(X)
    nonfinite = ~np.isfinite(X)
    if nonfinite.any():
        X[nonfinite] = np.nan
    col_means = np.nanmean(X, axis=0)
    col_means = np.where(np.isfinite(col_means), col_means, 0.0).astype(np.float32)
    nan_mask = np.isnan(X)
    if nan_mask.any():
        X[nan_mask] = np.take(col_means, np.where(nan_mask)[1])
    return X

def _robust_scale_clip(X: np.ndarray, clip_pct: float = 99.9) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64, order="C")
    lo = np.percentile(X, 100 - clip_pct, axis=0)
    hi = np.percentile(X, clip_pct, axis=0)
    X = np.clip(X, lo, hi, out=X)
    med = np.median(X, axis=0)
    q25 = np.percentile(X, 25, axis=0)
    q75 = np.percentile(X, 75, axis=0)
    iqr = q75 - q25
    scale = iqr / 1.349
    scale = np.where(scale > 0, scale, 1.0)
    X -= med
    X /= scale
    bad = ~np.isfinite(X)
    if bad.any():
        X[bad] = 0.0
    return X

# ----------------------------
# Regime model container
# ----------------------------
@dataclass
class RegimeModel:
    scaler: StandardScaler
    kmeans: MiniBatchKMeans
    feature_columns: List[str]
    raw_tags: List[str]
    n_pca_components: int
    train_hash: Optional[int] = None
    health_labels: Dict[int, str] = field(default_factory=dict)
    stats: Dict[int, Dict[str, float]] = field(default_factory=dict)
    meta: Dict[str, Any] = field(default_factory=dict)


def build_feature_basis(
    train_features: pd.DataFrame,
    score_features: pd.DataFrame,
    raw_train: Optional[pd.DataFrame],
    raw_score: Optional[pd.DataFrame],
    pca_detector: Optional[Any],
    cfg: Dict[str, Any],
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    """Construct a compact feature matrix for regime clustering."""
    basis_cfg = _cfg_get(cfg, "regimes.feature_basis", {})
    n_pca = int(basis_cfg.get("n_pca_components", 3))
    raw_tags_cfg = basis_cfg.get("raw_tags", []) or []

    train_parts: List[pd.DataFrame] = []
    score_parts: List[pd.DataFrame] = []
    used_raw_tags: List[str] = []
    n_pca_used = 0

    if pca_detector is not None and getattr(pca_detector, "pca", None) is not None:
        keep_cols = getattr(pca_detector, "keep_cols", list(train_features.columns))
        train_subset = train_features.reindex(columns=keep_cols).fillna(0.0)
        score_subset = score_features.reindex(columns=keep_cols).fillna(0.0)
        try:
            train_scaled = pca_detector.scaler.transform(train_subset.to_numpy(dtype=float, copy=False))
            score_scaled = pca_detector.scaler.transform(score_subset.to_numpy(dtype=float, copy=False))
            train_scores = pca_detector.pca.transform(train_scaled)
            score_scores = pca_detector.pca.transform(score_scaled)
            n_pca_available = train_scores.shape[1]
            n_pca_used = max(0, min(n_pca, n_pca_available))
            if n_pca_used > 0:
                cols = [f"PCA_{i+1}" for i in range(n_pca_used)]
                train_parts.append(pd.DataFrame(train_scores[:, :n_pca_used], index=train_features.index, columns=cols))
                score_parts.append(pd.DataFrame(score_scores[:, :n_pca_used], index=score_features.index, columns=cols))
        except Exception:
            n_pca_used = 0

    if raw_train is not None and raw_score is not None:
        available_tags = [tag for tag in raw_tags_cfg if tag in raw_train.columns]
        if available_tags:
            used_raw_tags = available_tags
            train_raw = raw_train.reindex(train_features.index)[available_tags].astype(float).ffill().bfill().fillna(0.0)
            score_raw = raw_score.reindex(score_features.index)[available_tags].astype(float).ffill().bfill().fillna(0.0)
            train_parts.append(train_raw)
            score_parts.append(score_raw)

    if not train_parts:
        fallback_cols = train_features.columns[:max(1, min(5, train_features.shape[1]))]
        train_parts.append(train_features[fallback_cols].fillna(0.0))
        score_parts.append(score_features[fallback_cols].fillna(0.0))

    train_basis = pd.concat(train_parts, axis=1)
    score_basis = pd.concat(score_parts, axis=1)
    train_basis = train_basis.ffill().bfill().fillna(0.0)
    score_basis = score_basis.ffill().bfill().fillna(0.0)

    meta = {
        "n_pca": n_pca_used,
        "raw_tags": used_raw_tags,
        "fallback_cols": list(train_basis.columns),
    }
    return train_basis, score_basis, meta


def _fit_kmeans_scaled(X: np.ndarray, cfg: Dict[str, Any]) -> Tuple[StandardScaler, MiniBatchKMeans, int, float, str]:
    """
    Fit KMeans with auto-k selection using silhouette scoring.
    Falls back to k=1 if all k values yield poor silhouette scores (<0.3).
    """
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    k_min = int(_cfg_get(cfg, "regimes.auto_k.k_min", 2))
    k_max = int(_cfg_get(cfg, "regimes.auto_k.k_max", 6))
    sil_sample = int(_cfg_get(cfg, "regimes.auto_k.sil_sample", 4000))
    random_state = int(_cfg_get(cfg, "regimes.auto_k.random_state", 17))
    
    # Threshold for k=1 fallback
    sil_min_threshold = float(_cfg_get(cfg, "regimes.quality.silhouette_min", 0.2))
    k1_fallback_threshold = 0.3  # If all k values have silhouette < 0.3, use k=1

    if X_scaled.shape[0] < k_min:
        k_min = max(1, int(X_scaled.shape[0]))
    if k_max < k_min:
        k_max = k_min

    best_model: Optional[MiniBatchKMeans] = None
    best_score = -np.inf
    best_metric = "silhouette"
    best_k = k_min
    all_scores = []  # Track all silhouette scores for k=1 fallback decision

    for k in range(k_min, k_max + 1):
        km = MiniBatchKMeans(
            n_clusters=k,
            batch_size=max(32, min(2048, max(512, X_scaled.shape[0] // 10) or 1)),
            n_init=10,
            random_state=random_state,
        )
        km.fit(X_scaled)
        labels = km.labels_
        uniq = np.unique(labels)
        if uniq.size < 2:
            score = -np.inf
            metric = "silhouette"
        else:
            try:
                sample_size = min(sil_sample, X_scaled.shape[0])
                score = silhouette_score(X_scaled, labels, sample_size=sample_size, random_state=random_state)
                metric = "silhouette"
                all_scores.append((k, score))
            except Exception:
                score = calinski_harabasz_score(X_scaled, labels)
                metric = "calinski_harabasz"
        if score > best_score:
            best_score = float(score)
            best_model = km
            best_metric = metric
            best_k = k

    # Single-cluster fallback: if all silhouette scores are poor, treat data as homogeneous
    if all_scores and all(s < k1_fallback_threshold for _, s in all_scores):
        print(f"[REGIME] All tested k values yielded silhouette < {k1_fallback_threshold}. Falling back to k=1 (homogeneous data).")
        print(f"[REGIME] Silhouette scores: {', '.join([f'k={k}: {s:.3f}' for k, s in all_scores])}")
        best_model = MiniBatchKMeans(
            n_clusters=1,
            n_init=10,
            random_state=random_state,
        )
        best_model.fit(X_scaled)
        best_score = 1.0  # Perfect silhouette for single cluster
        best_metric = "fallback_k1"
        best_k = 1

    if best_model is None:
        best_model = MiniBatchKMeans(
            n_clusters=max(1, min(2, X_scaled.shape[0])),
            n_init=10,
            random_state=random_state,
        )
        best_model.fit(X_scaled)
        best_score = -1.0
        best_metric = "fallback"
        best_k = best_model.n_clusters
    
    # Log final selection
    print(f"[REGIME] Auto-k selection complete: k={best_k}, {best_metric}={best_score:.3f} (range tested: k={k_min} to k={k_max})")
    if all_scores:
        print(f"[REGIME] Quality scores: {', '.join([f'k={k}: {s:.3f}' for k, s in sorted(all_scores)])}")

    return scaler, best_model, best_k, best_score, best_metric


def fit_regime_model(
    train_basis: pd.DataFrame,
    basis_meta: Dict[str, Any],
    cfg: Dict[str, Any],
    train_hash: Optional[int],
) -> RegimeModel:
    scaler, kmeans, best_k, best_score, best_metric = _fit_kmeans_scaled(train_basis.to_numpy(dtype=float, copy=False), cfg)
    quality_cfg = _cfg_get(cfg, "regimes.quality", {})
    sil_min = float(quality_cfg.get("silhouette_min", 0.2))
    calinski_min = float(quality_cfg.get("calinski_min", 50.0))
    quality_ok = True
    if best_metric == "silhouette":
        quality_ok = best_score >= sil_min
    elif best_metric == "calinski_harabasz":
        quality_ok = best_score >= calinski_min
    model = RegimeModel(
        scaler=scaler,
        kmeans=kmeans,
        feature_columns=list(train_basis.columns),
        raw_tags=basis_meta.get("raw_tags", []),
        n_pca_components=int(basis_meta.get("n_pca", 0)),
        train_hash=train_hash,
        meta={
            "best_k": best_k,
            "fit_score": best_score,
            "fit_metric": best_metric,
            "quality_ok": bool(quality_ok),
        },
    )
    return model


def predict_regime(model: RegimeModel, basis_df: pd.DataFrame) -> np.ndarray:
    aligned = basis_df.reindex(columns=model.feature_columns, fill_value=0.0).to_numpy(dtype=float, copy=False)
    X_scaled = model.scaler.transform(aligned)
    return model.kmeans.predict(X_scaled)


def update_health_labels(
    model: RegimeModel,
    labels: np.ndarray,
    fused_series: pd.Series | np.ndarray,
    cfg: Dict[str, Any],
) -> Dict[int, Dict[str, float]]:
    health_cfg = _cfg_get(cfg, "regimes.health", {})
    warn = float(health_cfg.get("fused_warn_z", 1.5))
    alert = float(health_cfg.get("fused_alert_z", 3.0))

    labels = np.asarray(labels, dtype=int)
    fused = pd.Series(fused_series).astype(float)

    stats: Dict[int, Dict[str, float]] = {}
    for label in np.unique(labels):
        mask = labels == label
        if not np.any(mask):
            continue
        fused_vals = fused.loc[mask]
        if fused_vals.empty:
            continue
        med = float(np.nanmedian(fused_vals))
        p95 = float(np.nanpercentile(np.abs(fused_vals), 95))
        count = int(mask.sum())
        if med >= alert:
            state = "critical"
        elif med >= warn:
            state = "suspect"
        else:
            state = "healthy"
        stats[int(label)] = {
            "median_fused": med,
            "p95_abs_fused": p95,
            "count": count,
            "state": state,
        }
        model.health_labels[int(label)] = state
    model.stats = stats
    return stats
def _persist_regime_error(e: Exception, models_dir: Path):
    """Helper to write error details to a file."""
    err_file = models_dir / "regime_persist.errors.txt"
    import traceback
    with err_file.open("w", encoding="utf-8") as f:
        f.write(f"Error type: {type(e).__name__}\n\n{traceback.format_exc()}")


def build_summary_dataframe(model: RegimeModel) -> pd.DataFrame:
    rows = []
    for label, stat in (model.stats or {}).items():
        row = {
            "regime": int(label),
            "state": model.health_labels.get(int(label), "unknown"),
            "median_fused": stat.get("median_fused", float("nan")),
            "p95_abs_fused": stat.get("p95_abs_fused", float("nan")),
            "count": stat.get("count", 0),
        }
        rows.append(row)
    return pd.DataFrame(rows, columns=["regime", "state", "median_fused", "p95_abs_fused", "count"])


def smooth_labels(labels: np.ndarray, passes: int = 1) -> np.ndarray:
    """Simple median filter-like smoothing over integer labels.

    Replaces isolated flips (A,B,A) with A; repeat for `passes` iterations.
    """
    if labels.size == 0 or passes <= 0:
        return labels
    smoothed = labels.astype(int, copy=True)
    for _ in range(passes):
        changed = False
        for i in range(1, len(smoothed) - 1):
            prev_label = smoothed[i - 1]
            next_label = smoothed[i + 1]
            if smoothed[i] != prev_label and prev_label == next_label:
                smoothed[i] = prev_label
                changed = True
        if not changed:
            break
    return smoothed

def smooth_transitions(
    labels: np.ndarray,
    timestamps: Optional[pd.Index] = None,
    *,
    min_dwell_samples: int = 0,
    min_dwell_seconds: Optional[float] = None,
) -> np.ndarray:
    """Enforce a minimum dwell time for regime labels.

    If a run of a label is shorter than the dwell threshold, it is replaced by
    the preceding label (or following when no preceding).

    Priority of thresholds:
    - If `min_dwell_seconds` and valid `timestamps` are provided, use time-based dwell.
    - Else if `min_dwell_samples` > 0, use sample-count dwell.
    - Else return labels unchanged.
    """
    arr = np.asarray(labels, dtype=int)
    n = arr.size
    if n == 0:
        return arr

    use_time = False
    if min_dwell_seconds and timestamps is not None and len(timestamps) == n:
        try:
            ts = pd.to_datetime(timestamps)
            if not ts.is_monotonic_increasing:
                ts = ts.sort_values()
            use_time = True
        except Exception:
            use_time = False

    if not use_time and min_dwell_samples <= 0:
        return arr

    out = arr.copy()
    # Identify contiguous segments
    start = 0
    while start < n:
        end = start + 1
        while end < n and arr[end] == arr[start]:
            end += 1
        # segment [start:end)
        seg_len = end - start
        violates = False
        if use_time:
            t0 = pd.Timestamp(ts[start])
            t1 = pd.Timestamp(ts[end - 1])
            # Approximate segment duration as inclusive range
            dur = (t1 - t0).total_seconds()
            violates = dur < float(min_dwell_seconds)
        else:
            violates = seg_len < int(min_dwell_samples)

        if violates:
            # Choose replacement label: prefer previous if exists else next
            repl = out[start - 1] if start > 0 else (out[end] if end < n else out[start])
            out[start:end] = repl
        start = end
    return out

# Timestamp parsing (fast, consistent, UTC)
def _to_datetime_mixed(s):
    try:
        return pd.to_datetime(s, format="mixed", errors="coerce")
    except TypeError:
        return pd.to_datetime(s, errors="coerce")

def _read_episodes_csv(p: Path) -> pd.DataFrame:
    if not p.exists():
        return pd.DataFrame(columns=["start_ts", "end_ts"])
    df = pd.read_csv(p, dtype={"start_ts": "string", "end_ts": "string"})
    df["start_ts"] = _to_datetime_mixed(df["start_ts"])
    df["end_ts"]   = _to_datetime_mixed(df["end_ts"])
    return df

def _read_scores_csv(p: Path) -> pd.DataFrame:
    if not p.exists():
        return pd.DataFrame()
    df = pd.read_csv(p, dtype={"timestamp": "string"})
    df["timestamp"] = _to_datetime_mixed(df["timestamp"])
    df = df.set_index("timestamp")
    return df[~df.index.isna()]

# -----------------------------------
# Core: fit auto-k with safe heuristics
# -----------------------------------
def _fit_auto_k(
    X: np.ndarray,
    *,
    k_min: int = 2,
    k_max: int = 6,
    pca_dim: int = 20,
    sil_sample: int = 4000,
    random_state: int = 17,
) -> Tuple[MiniBatchKMeans, Optional[PCA], int, float, str]:
    X = _finite_impute_inplace(X)
    n, d = X.shape

    if n < 4:
        km = MiniBatchKMeans(
            n_clusters=1,
            batch_size=max(32, min(2048, n or 1)),
            n_init="auto",
            random_state=random_state,
        )
        km.fit(X)
        return km, None, 1, 0.0, "degenerate"

    Xp_f64: Optional[np.ndarray] = None
    pca_obj: Optional[PCA] = None
    max_components = max(1, min(pca_dim, d, n - 1))
    if d > pca_dim and max_components >= 1:
        X_safe = _robust_scale_clip(X, clip_pct=99.9)
        pca = PCA(
            n_components=int(max_components),
            svd_solver="randomized",
            iterated_power=2,
            random_state=random_state,
        )
        Xp = pca.fit_transform(X_safe)
        bad = ~np.isfinite(Xp)
        if bad.any():
            Xp[bad] = 0.0
        Xp_f64 = Xp
        pca_obj = pca
    else:
        Xp_f64 = _robust_scale_clip(X, clip_pct=99.9)

    k_min = max(2, int(k_min))
    k_max = max(k_min, int(k_max))

    best_model: Optional[MiniBatchKMeans] = None
    best_k = k_min
    best_score = -1.0
    best_metric = "silhouette"

    for k in range(k_min, k_max + 1):
        km = MiniBatchKMeans(
            n_clusters=k,
            batch_size=max(32, min(2048, max(512, n // 10))),
            n_init="auto",
            random_state=random_state,
        )
        labels = km.fit_predict(Xp_f64)

        uniq = np.unique(labels).size
        if uniq < 2 or uniq >= len(labels):
            score = -1.0
            metric = "silhouette"
        else:
            try:
                ss = min(int(sil_sample), n)
                score = silhouette_score(
                    Xp_f64, labels, metric="euclidean", sample_size=ss, random_state=random_state
                )
                metric = "silhouette"
            except Exception:
                score = calinski_harabasz_score(Xp_f64, labels)
                metric = "calinski_harabasz"

        if score > best_score:
            best_score = float(score)
            best_model = km
            best_k = int(k)
            best_metric = metric

    assert best_model is not None
    return best_model, pca_obj, best_k, best_score, best_metric

# ------------------------------------------------
# Public API: label(score_df, ctx, score_out, cfg)
# ------------------------------------------------
def label(score_df, ctx: Dict[str, Any], score_out: Dict[str, Any], cfg: Dict[str, Any]):
    basis_train: Optional[pd.DataFrame] = ctx.get("regime_basis_train")
    basis_score: Optional[pd.DataFrame] = ctx.get("regime_basis_score")
    basis_meta: Dict[str, Any] = ctx.get("basis_meta") or {}
    regime_model: Optional[RegimeModel] = ctx.get("regime_model")
    basis_hash: Optional[int] = ctx.get("regime_basis_hash")

    out = dict(score_out or {})
    frame = out.get("frame")

    if basis_train is not None and basis_score is not None:
        if (
            regime_model is None
            or regime_model.feature_columns != list(basis_train.columns)
            or (basis_hash is not None and regime_model.train_hash != basis_hash)
        ):
            regime_model = fit_regime_model(basis_train, basis_meta, cfg, basis_hash)
        elif regime_model.train_hash is None and basis_hash is not None:
            regime_model.train_hash = basis_hash

        train_labels = predict_regime(regime_model, basis_train)
        score_labels = predict_regime(regime_model, basis_score)
        # Smoothing controls
        smooth_cfg = _cfg_get(cfg, "regimes.smoothing", {}) or {}
        passes = int(smooth_cfg.get("passes", 1))
        min_dwell_samples = int(smooth_cfg.get("min_dwell_samples", 0) or 0)
        min_dwell_seconds = smooth_cfg.get("min_dwell_seconds", None)
        try:
            min_dwell_seconds = float(min_dwell_seconds) if min_dwell_seconds is not None else None
        except Exception:
            min_dwell_seconds = None

        # 1) Label smoothing (median-like)
        train_labels = smooth_labels(train_labels, passes=passes)
        score_labels = smooth_labels(score_labels, passes=passes)
        # 2) Transition smoothing (min dwell)
        train_labels = smooth_transitions(train_labels, timestamps=basis_train.index if isinstance(basis_train.index, pd.DatetimeIndex) else None,
                                          min_dwell_samples=min_dwell_samples, min_dwell_seconds=min_dwell_seconds)
        score_labels = smooth_transitions(score_labels, timestamps=basis_score.index if isinstance(basis_score.index, pd.DatetimeIndex) else None,
                                          min_dwell_samples=min_dwell_samples, min_dwell_seconds=min_dwell_seconds)
        quality_ok = bool(regime_model.meta.get("quality_ok", True))

        out["regime_model"] = regime_model
        out["regime_labels_train"] = train_labels
        out["regime_labels"] = score_labels
        out["regime_k"] = int(regime_model.kmeans.n_clusters)
        out["regime_score"] = float(regime_model.meta.get("fit_score", 0.0))
        out["regime_metric"] = str(regime_model.meta.get("fit_metric", "silhouette"))
        out["regime_centers"] = _as_f32(regime_model.kmeans.cluster_centers_)
        out["regime_quality_ok"] = quality_ok

        if frame is not None:
            frame["regime_label"] = score_labels
            out["frame"] = frame
        return out

    return _legacy_label(score_df, ctx, out, cfg)


def _legacy_label(score_df, ctx: Dict[str, Any], out: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    k_min = _cfg_get(cfg, "regimes.auto_k.k_min", 2)
    k_max = _cfg_get(cfg, "regimes.auto_k.k_max", 6)
    pca_dim = _cfg_get(cfg, "regimes.auto_k.pca_dim", 20)
    sil_sample = _cfg_get(cfg, "regimes.auto_k.sil_sample", 4000)
    random_state = _cfg_get(cfg, "regimes.auto_k.random_state", 17)

    X_score = _finite_impute_inplace(score_df.to_numpy(copy=False))
    X_train = ctx.get("X_train", None)
    if X_train is not None:
        try:
            X_train = getattr(X_train, "to_numpy", lambda **_: X_train)(copy=False)
        except Exception:
            pass
        X_train = _finite_impute_inplace(X_train)

    use_train = isinstance(X_train, np.ndarray) and X_train.ndim == 2 and X_train.shape[0] >= 4
    X_fit = X_train if use_train else X_score

    model, pca_obj, k, sel_score, metric = _fit_auto_k(
        X_fit,
        k_min=k_min,
        k_max=k_max,
        pca_dim=pca_dim,
        sil_sample=sil_sample,
        random_state=random_state,
    )

    if pca_obj is not None:
        Xs = _robust_scale_clip(X_score, clip_pct=99.9)
        try:
            Xp = pca_obj.transform(Xs)
        except Exception:
            Xp = Xs[:, : int(pca_obj.n_components_)]
        bad = ~np.isfinite(Xp)
        if bad.any():
            Xp[bad] = 0.0
        X_pred = Xp
    else:
        X_pred = _robust_scale_clip(X_score, clip_pct=99.9)

    labels = model.predict(X_pred).astype(np.int32, copy=False)
    if use_train and X_train is not None:
        if pca_obj is not None:
            Xt = _robust_scale_clip(X_train, clip_pct=99.9)
            try:
                Xt = pca_obj.transform(Xt)
            except Exception:
                Xt = Xt[:, : int(pca_obj.n_components_)]
        else:
            Xt = _robust_scale_clip(X_train, clip_pct=99.9)
        out["regime_labels_train"] = model.predict(Xt).astype(np.int32, copy=False)

    out["regime_labels"] = labels
    out["regime_k"] = int(k)
    out["regime_score"] = float(sel_score)
    out["regime_metric"] = str(metric)
    # Smoothing controls
    smooth_cfg = _cfg_get(cfg, "regimes.smoothing", {}) or {}
    passes = int(smooth_cfg.get("passes", 1))
    min_dwell_samples = int(smooth_cfg.get("min_dwell_samples", 0) or 0)
    min_dwell_seconds = smooth_cfg.get("min_dwell_seconds", None)
    try:
        min_dwell_seconds = float(min_dwell_seconds) if min_dwell_seconds is not None else None
    except Exception:
        min_dwell_seconds = None
    labels = smooth_labels(labels, passes=passes)
    out["regime_labels"] = labels
    if "regime_labels_train" in out:
        train_labels = np.asarray(out["regime_labels_train"])  # type: ignore[assignment]
        train_labels = smooth_labels(train_labels, passes=passes)
        out["regime_labels_train"] = train_labels
    # Apply transition smoothing if we have timestamps
    ts_pred = score_df.index if isinstance(score_df.index, pd.DatetimeIndex) else None
    labels = smooth_transitions(labels, timestamps=ts_pred,
                                min_dwell_samples=min_dwell_samples, min_dwell_seconds=min_dwell_seconds)
    out["regime_labels"] = labels
    if "regime_labels_train" in out:
        tr = np.asarray(out["regime_labels_train"])  # type: ignore[assignment]
        ts_train = ctx.get("X_train_index") if isinstance(ctx.get("X_train_index"), pd.DatetimeIndex) else None
        tr = smooth_transitions(tr, timestamps=ts_train,
                                min_dwell_samples=min_dwell_samples, min_dwell_seconds=min_dwell_seconds)
        out["regime_labels_train"] = tr
    out["regime_quality_ok"] = True
    out["regime_centers"] = _as_f32(model.cluster_centers_)
    frame = out.get("frame")
    if frame is not None:
        frame["regime_label"] = labels
        out["frame"] = frame
    return out

# ------------------------------------------------
# Reporting hook: run(ctx)
# ------------------------------------------------
def run(ctx: Any) -> Dict[str, Any]:
    """
    Reporting function for the regime module.
    Generates a plot overlaying episodes on the fused score.
    """
    ep_path = ctx.run_dir / "episodes.csv"
    sc_path = ctx.run_dir / "scores.csv"
    if not ep_path.exists():
        return {"module":"regime","tables":[], "plots":[], "metrics":{},
                "error":{"type":"MissingFile","message":"episodes.csv not found"}}

    eps = _read_episodes_csv(ep_path)
    tables = []
    t_eps = ctx.tables_dir / "regime_episodes.csv"
    eps.to_csv(t_eps, index=False)
    tables.append({"name":"regime_episodes","path":str(t_eps)})

    summary_path = ctx.tables_dir / "regime_summary.csv"
    summary_df: Optional[pd.DataFrame] = None
    if summary_path.exists() and summary_path.stat().st_size > 0:
        summary_df = pd.read_csv(summary_path)
        tables.append({"name":"regime_summary","path":str(summary_path)})

    plots = []
    if sc_path.exists():
        sc = _read_scores_csv(sc_path)
        if "fused" in sc.columns and len(sc) > 0 and len(eps) > 0:
            fig = plt.figure(figsize=(12,4)); ax = plt.gca()
            sc["fused"].plot(ax=ax, linewidth=1)
            for _, r in eps.iterrows():
                if pd.notna(r["start_ts"]) and pd.notna(r["end_ts"]):
                    ax.axvspan(r["start_ts"], r["end_ts"], alpha=0.15, color="red")
            ax.set_title("Fused score with episode windows")
            ax.set_xlabel("")
            plt.tight_layout()
            p = ctx.plots_dir / "regime_overlay.png"
            fig.savefig(p, dpi=144, bbox_inches="tight"); plt.close(fig)
            plots.append({"title":"Episodes overlay","path":str(p),"caption":"Shaded = episodes"})

    # simple regime stability via episode durations
    eps = eps.sort_values(["start_ts","end_ts"])
    durations = (
        (eps["end_ts"] - eps["start_ts"]).dt.total_seconds().clip(lower=0)
        if not eps.empty else pd.Series([], dtype="float64")
    )
    metrics = {"episode_count": int(len(eps))}
    if summary_df is not None and not summary_df.empty:
        metrics["regime_count"] = int(summary_df["regime"].nunique())
        metrics["critical_regimes"] = int((summary_df["state"] == "critical").sum())
    if len(durations) >= 4:
        metrics["major_minor_ratio"] = float(
            (durations.quantile(0.75)+1e-9)/(durations.quantile(0.25)+1e-9)
        )

    return {"module":"regime","tables":tables,
            "plots":plots,"metrics":metrics}


# ----------------------------
# Model Persistence Functions
# ----------------------------

def save_regime_model(model: RegimeModel, models_dir: Path) -> None:
    """
    Save regime model with joblib persistence for sklearn objects.
    
    Saves:
    - regime_model.joblib: KMeans and StandardScaler objects
    - regime_model.json: Metadata (feature columns, health labels, stats)
    
    Args:
        model: RegimeModel to persist
        models_dir: Directory for model storage (typically artifacts/{EQUIP}/models)
    """
    from utils.logger import Console
    
    models_dir = Path(models_dir)
    models_dir.mkdir(parents=True, exist_ok=True)
    
    # Save sklearn objects with joblib
    joblib_path = models_dir / "regime_model.joblib"
    try:
        joblib.dump({
            'scaler': model.scaler,
            'kmeans': model.kmeans,
            'train_hash': model.train_hash,
        }, joblib_path)
        Console.info(f"[REGIME] Saved regime models (KMeans+Scaler) -> {joblib_path}")
    except Exception as e:
        Console.warn(f"[REGIME] Failed to save regime joblib: {e}")
        raise
    
    # Save metadata as JSON
    json_path = models_dir / "regime_model.json"
    metadata = {
        "feature_columns": model.feature_columns,
        "raw_tags": model.raw_tags,
        "n_pca_components": model.n_pca_components,
        "train_hash": model.train_hash,
        "health_labels": {str(k): str(v) for k, v in (model.health_labels or {}).items()},
        "stats": {
            str(k): {
                kk: (float(vv) if isinstance(vv, (int, float, np.floating)) else str(vv))
                for kk, vv in stat.items()
            }
            for k, stat in (model.stats or {}).items()
        },
        "meta": model.meta,
    }
    try:
        with json_path.open("w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
        Console.info(f"[REGIME] Saved regime metadata -> {json_path}")
    except Exception as e:
        Console.warn(f"[REGIME] Failed to save regime metadata: {e}")
        raise


def load_regime_model(models_dir: Path) -> Optional[RegimeModel]:
    """
    Load regime model from disk.
    
    Loads:
    - regime_model.joblib: KMeans and StandardScaler objects
    - regime_model.json: Metadata
    
    Args:
        models_dir: Directory containing model files
        
    Returns:
        RegimeModel if found and valid, None otherwise
    """
    from utils.logger import Console
    
    models_dir = Path(models_dir)
    joblib_path = models_dir / "regime_model.joblib"
    json_path = models_dir / "regime_model.json"
    
    # Check if both files exist
    if not joblib_path.exists():
        Console.info(f"[REGIME] No cached regime model found at {joblib_path}")
        return None
    
    if not json_path.exists():
        Console.warn(f"[REGIME] Regime joblib exists but metadata missing: {json_path}")
        return None
    
    try:
        # Load sklearn objects
        joblib_data = joblib.load(joblib_path)
        scaler = joblib_data['scaler']
        kmeans = joblib_data['kmeans']
        train_hash = joblib_data.get('train_hash')
        
        # Load metadata
        with json_path.open("r", encoding="utf-8") as f:
            metadata = json.load(f)
        
        # Reconstruct RegimeModel
        model = RegimeModel(
            scaler=scaler,
            kmeans=kmeans,
            feature_columns=metadata.get("feature_columns", []),
            raw_tags=metadata.get("raw_tags", []),
            n_pca_components=metadata.get("n_pca_components", 0),
            train_hash=train_hash,
            health_labels={int(k): v for k, v in metadata.get("health_labels", {}).items()},
            stats={int(k): v for k, v in metadata.get("stats", {}).items()},
            meta=metadata.get("meta", {}),
        )
        
        Console.info(f"[REGIME] Loaded cached regime model from {joblib_path}")
        Console.info(f"[REGIME]   - K={kmeans.n_clusters}, features={len(model.feature_columns)}, train_hash={train_hash}")
        return model
        
    except Exception as e:
        Console.warn(f"[REGIME] Failed to load regime model: {e}")
        return None


def detect_transient_states(
    data: pd.DataFrame,
    regime_labels: np.ndarray,
    cfg: Optional[Dict[str, Any]] = None
) -> np.ndarray:
    """
    REG-06: Detect transient operating states (startup, shutdown, steady, trip).
    
    Strategy:
    1. Calculate rate-of-change (ROC) for key sensor statistics
    2. Detect regime transitions
    3. Classify each timestamp as startup/shutdown/steady/trip/unknown
    
    Args:
        data: DataFrame with sensor readings (score data or features)
        regime_labels: Array of regime labels (aligned with data.index)
        cfg: Configuration dict with transient detection parameters
        
    Returns:
        Array of transient state labels (str) aligned with data.index
    """
    from utils.logger import Console
    
    transient_cfg = (cfg or {}).get("regimes", {}).get("transient_detection", {})
    enabled = transient_cfg.get("enabled", True)
    
    if not enabled:
        Console.info("[TRANSIENT] Detection disabled in config")
        return np.array(["steady"] * len(data), dtype=object)
    
    # Parameters
    roc_window = int(transient_cfg.get("roc_window", 5))  # Window for rate-of-change calculation
    roc_threshold_high = float(transient_cfg.get("roc_threshold_high", 3.0))  # High ROC → startup/shutdown
    roc_threshold_trip = float(transient_cfg.get("roc_threshold_trip", 5.0))  # Very high ROC → trip
    transition_lag = int(transient_cfg.get("transition_lag", 3))  # Samples after regime change = transient
    
    n_samples = len(data)
    states = np.array(["steady"] * n_samples, dtype=object)
    
    # 1. Calculate aggregate ROC (mean absolute rate-of-change across all sensors)
    try:
        # Get numeric columns
        numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
        if len(numeric_cols) == 0:
            Console.warn("[TRANSIENT] No numeric columns for ROC calculation")
            return states
        
        # Calculate rolling mean ROC
        data_numeric = data[numeric_cols].apply(pd.to_numeric, errors='coerce')
        
        # ROC = |x[t] - x[t-1]| / max(|x[t-1]|, 1e-9)
        roc_series = []
        for col in numeric_cols:
            series = data_numeric[col]
            diff = series.diff().abs()
            baseline = series.shift(1).abs().clip(lower=1e-9)
            roc_col = diff / baseline
            roc_series.append(roc_col)
        
        # Aggregate: mean ROC across all sensors
        roc_df = pd.DataFrame(roc_series).T
        aggregate_roc = roc_df.mean(axis=1, skipna=True).fillna(0.0)
        
        # Smooth with rolling mean
        aggregate_roc_smooth = aggregate_roc.rolling(window=roc_window, min_periods=1, center=False).mean()
        
    except Exception as roc_e:
        Console.warn(f"[TRANSIENT] ROC calculation failed: {roc_e}")
        aggregate_roc_smooth = pd.Series([0.0] * n_samples, index=data.index)
    
    # 2. Detect regime transitions
    regime_changes = np.zeros(n_samples, dtype=bool)
    if len(regime_labels) == n_samples:
        for i in range(1, n_samples):
            if regime_labels[i] != regime_labels[i-1]:
                regime_changes[i] = True
    
    # 3. Classify states
    for i in range(n_samples):
        roc = aggregate_roc_smooth.iloc[i]
        
        # Trip: very high ROC
        if roc >= roc_threshold_trip:
            states[i] = "trip"
        # High ROC: startup or shutdown
        elif roc >= roc_threshold_high:
            # Heuristic: if ROC is increasing → startup, if decreasing → shutdown
            if i > 0:
                prev_roc = aggregate_roc_smooth.iloc[i-1]
                if roc > prev_roc:
                    states[i] = "startup"
                else:
                    states[i] = "shutdown"
            else:
                states[i] = "startup"
        # Regime transition: mark next N samples as transient
        elif regime_changes[i]:
            for j in range(i, min(i + transition_lag, n_samples)):
                if states[j] == "steady":  # Don't overwrite trip/startup/shutdown
                    states[j] = "transient"
        # Default: steady
        # (already initialized)
    
    # Log state distribution
    state_counts = pd.Series(states).value_counts().to_dict()
    Console.info(f"[TRANSIENT] State distribution: {state_counts}")
    
    return states



