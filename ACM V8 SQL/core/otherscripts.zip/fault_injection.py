"""
Synthetic Fault Injection Module

Provides operators for injecting synthetic faults into sensor data streams
to validate ACM detection capabilities and generate labeled test data.

Fault Types:
- Step Change: Sudden offset/bias (e.g., sensor calibration drift)
- Spike: Brief anomaly (e.g., electrical noise, transient fault)
- Drift: Gradual trend (e.g., slow degradation)
- Stuck-at: Frozen value (e.g., sensor failure, communication loss)
- Noise: Increased random variation (e.g., bearing wear, turbulence)

Safety:
- Gated by --inject-faults CLI flag (disabled by default)
- Never modifies training data (only scoring data)
- All injections logged to ACM_FaultInjections table
- Preserves original data for validation
"""

from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime, timezone
import pandas as pd
import numpy as np
from pathlib import Path
import json

from utils.logger import Console


@dataclass
class FaultInjection:
    """Record of a single fault injection operation."""
    timestamp: datetime
    sensor_name: str
    operator_type: str
    parameters: Dict[str, Any]
    original_value: Optional[float]
    injected_value: Optional[float]
    run_id: Optional[str] = None
    equip_id: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for SQL insertion."""
        return {
            'RunID': self.run_id,
            'EquipID': self.equip_id,
            'Timestamp': self.timestamp,
            'SensorName': self.sensor_name,
            'OperatorType': self.operator_type,
            'Parameters': json.dumps(self.parameters),
            'OriginalValue': self.original_value,
            'InjectedValue': self.injected_value
        }


@dataclass
class FaultInjectionPlan:
    """Defines a fault injection scenario."""
    sensor_name: str
    operator_type: str
    start_time: pd.Timestamp
    end_time: pd.Timestamp
    parameters: Dict[str, Any] = field(default_factory=dict)
    description: str = ""
    
    def validate(self) -> Tuple[bool, str]:
        """Validate plan parameters."""
        if not self.sensor_name:
            return False, "sensor_name is required"
        if self.operator_type not in ['step', 'spike', 'drift', 'stuck-at', 'noise']:
            return False, f"Invalid operator_type: {self.operator_type}"
        if self.start_time >= self.end_time:
            return False, "start_time must be before end_time"
        return True, "OK"


class FaultInjector:
    """
    Manages synthetic fault injection for ACM validation.
    
    Usage:
        injector = FaultInjector(enabled=True, run_id=run_id, equip_id=equip_id)
        
        # Define fault plan
        plan = FaultInjectionPlan(
            sensor_name="Temperature_1",
            operator_type="step",
            start_time=pd.Timestamp("2024-01-15 10:00"),
            end_time=pd.Timestamp("2024-01-15 12:00"),
            parameters={"magnitude": 5.0}
        )
        
        # Apply to data
        modified_df, injections = injector.apply_plan(scores_df, plan)
        
        # Log to SQL
        injector.log_injections(sql_client, injections)
    """
    
    def __init__(self, 
                 enabled: bool = False,
                 run_id: Optional[str] = None,
                 equip_id: Optional[int] = None,
                 seed: Optional[int] = None):
        self.enabled = enabled
        self.run_id = run_id
        self.equip_id = equip_id
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.injection_log: List[FaultInjection] = []
        
        if enabled:
            Console.warn("[FAULT] Fault injection ENABLED - data will be modified!")
        else:
            Console.info("[FAULT] Fault injection disabled")
    
    def apply_plan(self, 
                   df: pd.DataFrame, 
                   plan: FaultInjectionPlan) -> Tuple[pd.DataFrame, List[FaultInjection]]:
        """
        Apply a fault injection plan to a DataFrame.
        
        Args:
            df: DataFrame with DatetimeIndex and sensor columns
            plan: Fault injection specification
        
        Returns:
            (modified_df, injection_records)
        """
        if not self.enabled:
            return df.copy(), []
        
        # Validate plan
        valid, msg = plan.validate()
        if not valid:
            Console.error(f"[FAULT] Invalid plan: {msg}")
            return df.copy(), []
        
        if plan.sensor_name not in df.columns:
            Console.warn(f"[FAULT] Sensor {plan.sensor_name} not found in data")
            return df.copy(), []
        
        # Create copy for modification
        modified_df = df.copy()
        injections = []
        
        # Select time window
        mask = (df.index >= plan.start_time) & (df.index <= plan.end_time)
        affected_indices = df.index[mask]
        
        if len(affected_indices) == 0:
            Console.warn(f"[FAULT] No data points in time window {plan.start_time} to {plan.end_time}")
            return modified_df, []
        
        Console.info(f"[FAULT] Applying {plan.operator_type} to {plan.sensor_name} ({len(affected_indices)} points)")
        
        # Apply operator
        if plan.operator_type == 'step':
            modified_df, injections = self._apply_step(modified_df, plan, affected_indices)
        elif plan.operator_type == 'spike':
            modified_df, injections = self._apply_spike(modified_df, plan, affected_indices)
        elif plan.operator_type == 'drift':
            modified_df, injections = self._apply_drift(modified_df, plan, affected_indices)
        elif plan.operator_type == 'stuck-at':
            modified_df, injections = self._apply_stuck_at(modified_df, plan, affected_indices)
        elif plan.operator_type == 'noise':
            modified_df, injections = self._apply_noise(modified_df, plan, affected_indices)
        
        self.injection_log.extend(injections)
        return modified_df, injections
    
    def _apply_step(self, 
                    df: pd.DataFrame, 
                    plan: FaultInjectionPlan, 
                    indices: pd.DatetimeIndex) -> Tuple[pd.DataFrame, List[FaultInjection]]:
        """Apply step change (sudden offset)."""
        magnitude = plan.parameters.get('magnitude', 0.0)
        injections = []
        
        for idx in indices:
            original = df.loc[idx, plan.sensor_name]
            if pd.notna(original):
                modified = float(original) + magnitude
                df.loc[idx, plan.sensor_name] = modified
                
                injections.append(FaultInjection(
                    timestamp=idx.to_pydatetime().replace(tzinfo=None),
                    sensor_name=plan.sensor_name,
                    operator_type='step',
                    parameters={'magnitude': magnitude},
                    original_value=float(original),
                    injected_value=modified,
                    run_id=self.run_id,
                    equip_id=self.equip_id
                ))
        
        Console.info(f"[FAULT] Step injection: {len(injections)} points modified by {magnitude:+.2f}")
        return df, injections
    
    def _apply_spike(self, 
                     df: pd.DataFrame, 
                     plan: FaultInjectionPlan, 
                     indices: pd.DatetimeIndex) -> Tuple[pd.DataFrame, List[FaultInjection]]:
        """Apply transient spike (brief anomaly)."""
        magnitude = plan.parameters.get('magnitude', 0.0)
        duration_points = plan.parameters.get('duration_points', 1)
        injections = []
        
        # Apply spike at random location within window
        if len(indices) < duration_points:
            Console.warn(f"[FAULT] Window too short for spike duration {duration_points}")
            return df, []
        
        start_idx = self.rng.integers(0, len(indices) - duration_points + 1)
        spike_indices = indices[start_idx:start_idx + duration_points]
        
        for idx in spike_indices:
            original = df.loc[idx, plan.sensor_name]
            if pd.notna(original):
                modified = float(original) + magnitude
                df.loc[idx, plan.sensor_name] = modified
                
                injections.append(FaultInjection(
                    timestamp=idx.to_pydatetime().replace(tzinfo=None),
                    sensor_name=plan.sensor_name,
                    operator_type='spike',
                    parameters={'magnitude': magnitude, 'duration_points': duration_points},
                    original_value=float(original),
                    injected_value=modified,
                    run_id=self.run_id,
                    equip_id=self.equip_id
                ))
        
        Console.info(f"[FAULT] Spike injection: {len(injections)} points modified by {magnitude:+.2f}")
        return df, injections
    
    def _apply_drift(self, 
                     df: pd.DataFrame, 
                     plan: FaultInjectionPlan, 
                     indices: pd.DatetimeIndex) -> Tuple[pd.DataFrame, List[FaultInjection]]:
        """Apply gradual drift (slow trend)."""
        rate = plan.parameters.get('rate', 0.0)  # units per point
        injections = []
        
        for i, idx in enumerate(indices):
            original = df.loc[idx, plan.sensor_name]
            if pd.notna(original):
                drift_amount = rate * i
                modified = float(original) + drift_amount
                df.loc[idx, plan.sensor_name] = modified
                
                injections.append(FaultInjection(
                    timestamp=idx.to_pydatetime().replace(tzinfo=None),
                    sensor_name=plan.sensor_name,
                    operator_type='drift',
                    parameters={'rate': rate, 'drift_amount': drift_amount},
                    original_value=float(original),
                    injected_value=modified,
                    run_id=self.run_id,
                    equip_id=self.equip_id
                ))
        
        total_drift = rate * len(indices)
        Console.info(f"[FAULT] Drift injection: {len(injections)} points, total drift={total_drift:.2f}")
        return df, injections
    
    def _apply_stuck_at(self, 
                        df: pd.DataFrame, 
                        plan: FaultInjectionPlan, 
                        indices: pd.DatetimeIndex) -> Tuple[pd.DataFrame, List[FaultInjection]]:
        """Apply stuck-at fault (frozen value)."""
        # Freeze at first value in window or specified value
        freeze_value = plan.parameters.get('value')
        injections = []
        
        if freeze_value is None:
            freeze_value = df.loc[indices[0], plan.sensor_name]
            if pd.isna(freeze_value):
                Console.warn(f"[FAULT] Cannot freeze - first value is NaN")
                return df, []
        
        for idx in indices:
            original = df.loc[idx, plan.sensor_name]
            if pd.notna(original):
                df.loc[idx, plan.sensor_name] = freeze_value
                
                injections.append(FaultInjection(
                    timestamp=idx.to_pydatetime().replace(tzinfo=None),
                    sensor_name=plan.sensor_name,
                    operator_type='stuck-at',
                    parameters={'freeze_value': float(freeze_value)},
                    original_value=float(original),
                    injected_value=freeze_value,
                    run_id=self.run_id,
                    equip_id=self.equip_id
                ))
        
        Console.info(f"[FAULT] Stuck-at injection: {len(injections)} points frozen at {freeze_value:.2f}")
        return df, injections
    
    def _apply_noise(self, 
                     df: pd.DataFrame, 
                     plan: FaultInjectionPlan, 
                     indices: pd.DatetimeIndex) -> Tuple[pd.DataFrame, List[FaultInjection]]:
        """Apply increased noise (random variation)."""
        std_multiplier = plan.parameters.get('std_multiplier', 2.0)
        injections = []
        
        # Calculate baseline std from data
        baseline_values = df.loc[indices, plan.sensor_name].dropna()
        if len(baseline_values) < 2:
            Console.warn(f"[FAULT] Insufficient data for noise injection")
            return df, []
        
        baseline_std = baseline_values.std()
        noise_std = baseline_std * std_multiplier
        
        for idx in indices:
            original = df.loc[idx, plan.sensor_name]
            if pd.notna(original):
                noise = self.rng.normal(0, noise_std)
                modified = float(original) + noise
                df.loc[idx, plan.sensor_name] = modified
                
                injections.append(FaultInjection(
                    timestamp=idx.to_pydatetime().replace(tzinfo=None),
                    sensor_name=plan.sensor_name,
                    operator_type='noise',
                    parameters={'std_multiplier': std_multiplier, 'baseline_std': float(baseline_std), 'noise_std': float(noise_std)},
                    original_value=float(original),
                    injected_value=modified,
                    run_id=self.run_id,
                    equip_id=self.equip_id
                ))
        
        Console.info(f"[FAULT] Noise injection: {len(injections)} points, std={noise_std:.2f}")
        return df, injections
    
    def log_injections(self, sql_client, injections: Optional[List[FaultInjection]] = None):
        """
        Log fault injections to ACM_FaultInjections SQL table.
        
        Args:
            sql_client: SQL connection
            injections: List of injections to log (defaults to self.injection_log)
        """
        if injections is None:
            injections = self.injection_log
        
        if not injections:
            Console.info("[FAULT] No injections to log")
            return
        
        try:
            # Convert to DataFrame
            records = [inj.to_dict() for inj in injections]
            df = pd.DataFrame(records)
            
            # Ensure CreatedAt column
            df['CreatedAt'] = datetime.now().replace(tzinfo=None)
            
            # Bulk insert
            columns = df.columns.tolist()
            cols_str = ", ".join(f"[{c}]" for c in columns)
            placeholders = ", ".join(["?"] * len(columns))
            insert_sql = f"INSERT INTO dbo.ACM_FaultInjections ({cols_str}) VALUES ({placeholders})"
            
            with sql_client.cursor() as cur:
                try:
                    cur.fast_executemany = True
                except:
                    pass
                
                records = [tuple(row) for row in df[columns].itertuples(index=False, name=None)]
                cur.executemany(insert_sql, records)
            
            if hasattr(sql_client, "conn"):
                sql_client.conn.commit()
            elif hasattr(sql_client, "commit"):
                sql_client.commit()
            
            Console.info(f"[FAULT] Logged {len(injections)} fault injections to SQL")
            
        except Exception as e:
            Console.error(f"[FAULT] Failed to log injections: {e}")
    
    def save_plan(self, plan: FaultInjectionPlan, filepath: Path):
        """Save fault injection plan to JSON file."""
        plan_dict = {
            'sensor_name': plan.sensor_name,
            'operator_type': plan.operator_type,
            'start_time': plan.start_time.isoformat(),
            'end_time': plan.end_time.isoformat(),
            'parameters': plan.parameters,
            'description': plan.description
        }
        
        with open(filepath, 'w') as f:
            json.dump(plan_dict, f, indent=2)
        
        Console.info(f"[FAULT] Saved plan to {filepath}")
    
    @staticmethod
    def load_plan(filepath: Path) -> FaultInjectionPlan:
        """Load fault injection plan from JSON file."""
        with open(filepath, 'r') as f:
            plan_dict = json.load(f)
        
        return FaultInjectionPlan(
            sensor_name=plan_dict['sensor_name'],
            operator_type=plan_dict['operator_type'],
            start_time=pd.Timestamp(plan_dict['start_time']),
            end_time=pd.Timestamp(plan_dict['end_time']),
            parameters=plan_dict.get('parameters', {}),
            description=plan_dict.get('description', '')
        )
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary of all injections performed."""
        if not self.injection_log:
            return {"total_injections": 0}
        
        by_type = {}
        for inj in self.injection_log:
            by_type[inj.operator_type] = by_type.get(inj.operator_type, 0) + 1
        
        sensors_affected = set(inj.sensor_name for inj in self.injection_log)
        
        return {
            "total_injections": len(self.injection_log),
            "by_type": by_type,
            "sensors_affected": len(sensors_affected),
            "sensor_list": sorted(sensors_affected)
        }

