"""
Backtest Harness for ACM V6

Provides historical runner for validation and auto-tuning feedback.
Runs ACM on past data windows and tracks performance metrics.

Metrics:
- FP Rate: False positives per hour
- Latency: Runtime duration
- Coverage: % of sensors successfully evaluated
- Detection Rate: % of known defects detected
- Alert Duration: Time spent in alert zones

Features:
- Sliding window runner across date ranges
- Performance metric tracking
- SQL persistence (ACM_BacktestResults)
- Auto-tuning integration
- Configurable window sizes and step intervals
"""

from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
import pandas as pd
import numpy as np
import time

from utils.logger import Console
from core.acm_main import run_acm_pipeline  # Will need integration


@dataclass
class BacktestWindow:
    """Represents a single backtest time window."""
    window_start: pd.Timestamp
    window_end: pd.Timestamp
    equip_id: int
    config: Dict[str, Any]
    ground_truth: Optional[pd.DataFrame] = None  # Known good/bad periods
    
    def duration_hours(self) -> float:
        """Calculate window duration in hours."""
        return (self.window_end - self.window_start).total_seconds() / 3600
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'window_start': self.window_start,
            'window_end': self.window_end,
            'equip_id': self.equip_id,
            'duration_hours': self.duration_hours()
        }


@dataclass
class BacktestResult:
    """Results from a single backtest window."""
    run_id: str
    equip_id: int
    window_start: pd.Timestamp
    window_end: pd.Timestamp
    fp_rate: float  # False positives per hour
    latency_seconds: float  # Runtime duration
    coverage_pct: float  # % of sensors evaluated
    detection_rate: Optional[float] = None  # % of known defects detected
    alert_duration_hours: float = 0.0  # Time in alert zones
    health_final: str = "UNKNOWN"
    total_sensors: int = 0
    sensors_evaluated: int = 0
    episodes_detected: int = 0
    metrics_json: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().replace(tzinfo=None)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for SQL insertion."""
        import json
        return {
            'RunID': self.run_id,
            'EquipID': self.equip_id,
            'WindowStart': self.window_start.to_pydatetime().replace(tzinfo=None),
            'WindowEnd': self.window_end.to_pydatetime().replace(tzinfo=None),
            'FPRate': self.fp_rate,
            'LatencySeconds': self.latency_seconds,
            'CoveragePct': self.coverage_pct,
            'DetectionRate': self.detection_rate,
            'AlertDurationHours': self.alert_duration_hours,
            'HealthFinal': self.health_final,
            'TotalSensors': self.total_sensors,
            'SensorsEvaluated': self.sensors_evaluated,
            'EpisodesDetected': self.episodes_detected,
            'MetricsJSON': json.dumps(self.metrics_json) if self.metrics_json else None,
            'CreatedAt': self.created_at
        }


class BacktestHarness:
    """
    Historical runner for ACM validation and auto-tuning.
    
    Usage:
        harness = BacktestHarness(sql_client=sql_client)
        
        # Define backtest period
        results = harness.run_backtest(
            equip_id=101,
            start_date=pd.Timestamp("2024-01-01"),
            end_date=pd.Timestamp("2024-01-07"),
            window_hours=24,
            step_hours=12,
            config=cfg
        )
        
        # Analyze results
        summary = harness.summarize_results(results)
        
        # Persist to SQL
        harness.save_results(results)
    """
    
    def __init__(self, sql_client=None, enable_sql: bool = True):
        self.sql_client = sql_client
        self.enable_sql = enable_sql and sql_client is not None
        self.results: List[BacktestResult] = []
        
        if self.enable_sql:
            Console.info("[BACKTEST] SQL logging enabled")
        else:
            Console.warn("[BACKTEST] SQL logging disabled")
    
    def generate_windows(self,
                         start_date: pd.Timestamp,
                         end_date: pd.Timestamp,
                         window_hours: float = 24,
                         step_hours: float = 12,
                         equip_id: int = 0,
                         config: Optional[Dict[str, Any]] = None) -> List[BacktestWindow]:
        """
        Generate sliding windows for backtest.
        
        Args:
            start_date: Start of backtest period
            end_date: End of backtest period
            window_hours: Window duration in hours
            step_hours: Step between windows in hours
            equip_id: Equipment ID
            config: ACM configuration
        
        Returns:
            List of BacktestWindow objects
        """
        windows = []
        current_start = start_date
        window_delta = timedelta(hours=window_hours)
        step_delta = timedelta(hours=step_hours)
        
        while current_start + window_delta <= end_date:
            current_end = current_start + window_delta
            
            windows.append(BacktestWindow(
                window_start=current_start,
                window_end=current_end,
                equip_id=equip_id,
                config=config or {}
            ))
            
            current_start += step_delta
        
        Console.info(f"[BACKTEST] Generated {len(windows)} windows ({window_hours}h window, {step_hours}h step)")
        return windows
    
    def run_window(self, window: BacktestWindow) -> Optional[BacktestResult]:
        """
        Run ACM on a single backtest window.
        
        Args:
            window: Backtest window specification
        
        Returns:
            BacktestResult or None if run failed
        """
        start_time = time.time()
        run_id = f"backtest_{window.equip_id}_{window.window_start.strftime('%Y%m%d_%H%M%S')}"
        
        Console.info(f"[BACKTEST] Running window {window.window_start} to {window.window_end}")
        
        try:
            # TODO: Integrate with actual ACM pipeline
            # For now, create placeholder result
            # Real implementation would call:
            # result = run_acm_pipeline(
            #     equip_id=window.equip_id,
            #     start_time=window.window_start,
            #     end_time=window.window_end,
            #     config=window.config
            # )
            
            # Placeholder metrics
            latency = time.time() - start_time
            
            # Calculate metrics (would come from actual ACM run)
            fp_rate = self._calculate_fp_rate(window, None)
            coverage = self._calculate_coverage(window, None)
            alert_duration = self._calculate_alert_duration(window, None)
            
            result = BacktestResult(
                run_id=run_id,
                equip_id=window.equip_id,
                window_start=window.window_start,
                window_end=window.window_end,
                fp_rate=fp_rate,
                latency_seconds=latency,
                coverage_pct=coverage,
                alert_duration_hours=alert_duration,
                health_final="GOOD",  # Would come from ACM result
                total_sensors=0,  # Would come from ACM result
                sensors_evaluated=0,  # Would come from ACM result
                episodes_detected=0  # Would come from ACM result
            )
            
            self.results.append(result)
            Console.info(f"[BACKTEST] Window completed: FP_rate={fp_rate:.2f}/hr, latency={latency:.1f}s")
            return result
            
        except Exception as e:
            Console.error(f"[BACKTEST] Window failed: {e}")
            import traceback
            Console.error(f"[BACKTEST] Traceback: {traceback.format_exc()}")
            return None
    
    def run_backtest(self,
                     equip_id: int,
                     start_date: pd.Timestamp,
                     end_date: pd.Timestamp,
                     window_hours: float = 24,
                     step_hours: float = 12,
                     config: Optional[Dict[str, Any]] = None) -> List[BacktestResult]:
        """
        Run full backtest across date range.
        
        Args:
            equip_id: Equipment ID
            start_date: Start of backtest period
            end_date: End of backtest period
            window_hours: Window duration in hours
            step_hours: Step between windows in hours
            config: ACM configuration
        
        Returns:
            List of BacktestResult objects
        """
        Console.info(f"[BACKTEST] Starting backtest: {start_date} to {end_date}")
        Console.info(f"[BACKTEST] Window: {window_hours}h, Step: {step_hours}h")
        
        # Generate windows
        windows = self.generate_windows(
            start_date=start_date,
            end_date=end_date,
            window_hours=window_hours,
            step_hours=step_hours,
            equip_id=equip_id,
            config=config
        )
        
        # Run each window
        results = []
        for i, window in enumerate(windows, 1):
            Console.info(f"[BACKTEST] Window {i}/{len(windows)}")
            result = self.run_window(window)
            if result:
                results.append(result)
        
        # Save to SQL
        if self.enable_sql and results:
            self.save_results(results)
        
        Console.info(f"[BACKTEST] Completed {len(results)}/{len(windows)} windows")
        return results
    
    def _calculate_fp_rate(self, window: BacktestWindow, acm_result) -> float:
        """
        Calculate false positive rate (FP per hour).
        
        Requires ground truth data to identify false positives.
        If no ground truth, uses proxy metrics.
        """
        # TODO: Implement with ground truth
        # For now, use episode count as proxy
        # Real implementation: compare episodes to known good periods
        
        if acm_result and hasattr(acm_result, 'episodes'):
            fp_count = len(acm_result.episodes)  # Assuming all are FPs without ground truth
            duration_hours = window.duration_hours()
            return fp_count / duration_hours if duration_hours > 0 else 0.0
        
        return 0.0  # Placeholder
    
    def _calculate_coverage(self, window: BacktestWindow, acm_result) -> float:
        """Calculate sensor coverage percentage."""
        if acm_result and hasattr(acm_result, 'total_sensors') and hasattr(acm_result, 'sensors_evaluated'):
            if acm_result.total_sensors > 0:
                return (acm_result.sensors_evaluated / acm_result.total_sensors) * 100
        
        return 100.0  # Placeholder - assume full coverage
    
    def _calculate_alert_duration(self, window: BacktestWindow, acm_result) -> float:
        """Calculate total time spent in alert zones (hours)."""
        if acm_result and hasattr(acm_result, 'scores'):
            # Count points in ALERT/BAD zones
            alert_mask = acm_result.scores.get('health_zone', pd.Series()).isin(['ALERT', 'BAD'])
            alert_points = alert_mask.sum()
            
            # Estimate hours (assuming 5-min intervals)
            return (alert_points * 5) / 60
        
        return 0.0  # Placeholder
    
    def save_results(self, results: List[BacktestResult]):
        """
        Save backtest results to SQL.
        
        Args:
            results: List of BacktestResult objects
        """
        if not self.enable_sql:
            Console.warn("[BACKTEST] SQL logging disabled, skipping save")
            return
        
        if not results:
            Console.info("[BACKTEST] No results to save")
            return
        
        try:
            # Convert to DataFrame
            records = [res.to_dict() for res in results]
            df = pd.DataFrame(records)
            
            # Bulk insert
            columns = df.columns.tolist()
            cols_str = ", ".join(f"[{c}]" for c in columns)
            placeholders = ", ".join(["?"] * len(columns))
            insert_sql = f"INSERT INTO dbo.ACM_BacktestResults ({cols_str}) VALUES ({placeholders})"
            
            with self.sql_client.cursor() as cur:
                try:
                    cur.fast_executemany = True
                except:
                    pass
                
                records = [tuple(row) for row in df[columns].itertuples(index=False, name=None)]
                cur.executemany(insert_sql, records)
            
            if hasattr(self.sql_client, "conn"):
                self.sql_client.conn.commit()
            elif hasattr(self.sql_client, "commit"):
                self.sql_client.commit()
            
            Console.info(f"[BACKTEST] Saved {len(results)} results to SQL")
            
        except Exception as e:
            Console.error(f"[BACKTEST] Failed to save results: {e}")
    
    def summarize_results(self, results: Optional[List[BacktestResult]] = None) -> Dict[str, Any]:
        """
        Generate summary statistics from backtest results.
        
        Args:
            results: List of results (defaults to self.results)
        
        Returns:
            Dictionary with summary statistics
        """
        if results is None:
            results = self.results
        
        if not results:
            return {"total_windows": 0}
        
        fp_rates = [r.fp_rate for r in results]
        latencies = [r.latency_seconds for r in results]
        coverages = [r.coverage_pct for r in results]
        
        summary = {
            "total_windows": len(results),
            "fp_rate": {
                "mean": np.mean(fp_rates),
                "median": np.median(fp_rates),
                "std": np.std(fp_rates),
                "min": np.min(fp_rates),
                "max": np.max(fp_rates)
            },
            "latency_seconds": {
                "mean": np.mean(latencies),
                "median": np.median(latencies),
                "std": np.std(latencies),
                "min": np.min(latencies),
                "max": np.max(latencies)
            },
            "coverage_pct": {
                "mean": np.mean(coverages),
                "median": np.median(coverages),
                "min": np.min(coverages),
                "max": np.max(coverages)
            },
            "period": {
                "start": min(r.window_start for r in results),
                "end": max(r.window_end for r in results)
            }
        }
        
        return summary
    
    def log_summary(self, results: Optional[List[BacktestResult]] = None):
        """Print summary report to console."""
        summary = self.summarize_results(results)
        
        if summary["total_windows"] == 0:
            Console.info("[BACKTEST] No results to summarize")
            return
        
        Console.info("[BACKTEST] === Summary Report ===")
        Console.info(f"[BACKTEST] Total windows: {summary['total_windows']}")
        Console.info(f"[BACKTEST] Period: {summary['period']['start']} to {summary['period']['end']}")
        Console.info(f"[BACKTEST] FP Rate: {summary['fp_rate']['mean']:.2f} ± {summary['fp_rate']['std']:.2f} per hour")
        Console.info(f"[BACKTEST]   Range: {summary['fp_rate']['min']:.2f} - {summary['fp_rate']['max']:.2f}")
        Console.info(f"[BACKTEST] Latency: {summary['latency_seconds']['mean']:.1f} ± {summary['latency_seconds']['std']:.1f} seconds")
        Console.info(f"[BACKTEST]   Range: {summary['latency_seconds']['min']:.1f} - {summary['latency_seconds']['max']:.1f}")
        Console.info(f"[BACKTEST] Coverage: {summary['coverage_pct']['mean']:.1f}% (median {summary['coverage_pct']['median']:.1f}%)")
    
    def get_tuning_recommendation(self, target_fp_rate: float = 0.5) -> Dict[str, Any]:
        """
        Generate auto-tuning recommendation based on backtest results.
        
        Args:
            target_fp_rate: Desired false positive rate (per hour)
        
        Returns:
            Dictionary with tuning recommendations
        """
        if not self.results:
            return {"recommendation": "No data for tuning"}
        
        summary = self.summarize_results()
        current_fp_rate = summary['fp_rate']['mean']
        
        # Simple tuning logic (can be made more sophisticated)
        recommendation = {}
        
        if current_fp_rate > target_fp_rate:
            # Too many false positives - increase thresholds
            multiplier = min(current_fp_rate / target_fp_rate, 2.0)  # Cap at 2x increase
            recommendation['action'] = 'increase_thresholds'
            recommendation['multiplier'] = multiplier
            recommendation['reason'] = f"FP rate ({current_fp_rate:.2f}/hr) exceeds target ({target_fp_rate:.2f}/hr)"
        elif current_fp_rate < target_fp_rate * 0.5:
            # Too few detections - decrease thresholds
            multiplier = max(current_fp_rate / target_fp_rate, 0.5)  # Cap at 0.5x decrease
            recommendation['action'] = 'decrease_thresholds'
            recommendation['multiplier'] = multiplier
            recommendation['reason'] = f"FP rate ({current_fp_rate:.2f}/hr) well below target ({target_fp_rate:.2f}/hr)"
        else:
            # Within acceptable range
            recommendation['action'] = 'no_change'
            recommendation['reason'] = f"FP rate ({current_fp_rate:.2f}/hr) within target range"
        
        recommendation['current_fp_rate'] = current_fp_rate
        recommendation['target_fp_rate'] = target_fp_rate
        
        return recommendation

