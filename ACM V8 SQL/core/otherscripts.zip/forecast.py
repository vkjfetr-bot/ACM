# core/forecast.py
"""
Per-sensor forecasting and residual analysis module.
Implements an AR(1) baseline model for each sensor to generate residuals.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any, Dict, Tuple, Optional, Literal
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Import Console for logging (optional - will work without it)
try:
    from utils.console import Console
except ImportError:
    # Fallback if Console not available
    class Console:
        @staticmethod
        def warn(msg):
            print(f"WARNING: {msg}")


class AR1Detector:
    """
    Per-sensor AR(1) baseline model for residual scoring.
    Calculates AR(1) coefficients (phi) and mean (mu) for each sensor.
    Scores new data by calculating the absolute z-score of the residuals, normalized
    by the TRAIN-time residual standard deviation (important for anomaly sensitivity).
    """
    def __init__(self, ar1_cfg: Dict[str, Any] | None = None):
        """
        Initializes the AR(1) detector.

        Args:
            ar1_cfg (Dict[str, Any]): Configuration for the AR(1) model.
                                      Currently not used, but can be extended for smoothing etc.
        """
        self.cfg = ar1_cfg or {}
        # numeric guards
        self._eps: float = float(self.cfg.get("eps", 1e-9))
        self._phi_cap: float = float(self.cfg.get("phi_cap", 0.999))  # stability clamp
        self._sd_floor: float = float(self.cfg.get("sd_floor", 1e-6))
        # fuse strategy
        self._fuse: Literal["mean","median","p95"] = self.cfg.get("fuse", "mean")
        # trained params per column: (phi, mu)
        self.phimap: Dict[str, Tuple[float, float]] = {}
        # TRAIN residual std per column for normalization
        self.sdmap: Dict[str, float] = {}
        self._is_fitted = False

    def fit(self, X: pd.DataFrame) -> "AR1Detector":
        """
        Fits the AR(1) model for each column in the training data.

        Args:
            X (pd.DataFrame): The training feature matrix.
        """
        self.phimap = {}
        self.sdmap = {}
        if not isinstance(X, pd.DataFrame) or X.shape[0] == 0:
            # nothing to fit; leave maps empty but mark fitted for graceful no-op scoring
            self._is_fitted = True
            return self

        for c in X.columns:
            col = X[c].to_numpy(copy=False, dtype=np.float32)
            finite = np.isfinite(col)
            x = col[finite]
            if x.size < 3:
                mu = float(np.nanmean(col)) if x.size else 0.0
                if not np.isfinite(mu):
                    mu = 0.0
                phi = 0.0
                self.phimap[c] = (phi, mu)
                # residuals are deviations from mu here
                resid = (x - mu) if x.size else np.array([0.0], dtype=np.float32)
                sd = float(np.std(resid)) if resid.size else self._sd_floor
                self.sdmap[c] = max(sd, self._sd_floor)
                continue
            mu = float(np.nanmean(x))
            if not np.isfinite(mu):
                mu = 0.0
            xc = x - mu
            num = float(np.dot(xc[1:], xc[:-1]))
            den = float(np.dot(xc[:-1], xc[:-1])) + self._eps
            phi = num / den
            # clamp to ensure stationarity-ish behavior
            if phi > self._phi_cap:
                phi = self._phi_cap
            elif phi < -self._phi_cap:
                phi = -self._phi_cap
            self.phimap[c] = (phi, mu)
            # compute TRAIN residuals & std for normalization during score()
            # use one-step AR(1) with warm start at mu
            x_shift = np.empty_like(x, dtype=np.float32)
            x_shift[0] = mu
            x_shift[1:] = x[:-1]
            pred = (x_shift - mu) * phi + mu
            resid = x - pred
            sd = float(np.std(resid))
            self.sdmap[c] = max(sd, self._sd_floor)
        self._is_fitted = True
        return self

    def score(self, X: pd.DataFrame, return_per_sensor: bool = False) -> np.ndarray | Tuple[np.ndarray, pd.DataFrame]:
        """
        Calculates absolute z-scores of residuals using TRAIN-time residual std.

        Args:
            X (pd.DataFrame): The scoring feature matrix.
            return_per_sensor (bool): If True, also returns a DataFrame of per-sensor |z|.

        Returns:
            np.ndarray: fused absolute z-scores of residuals (len == len(X));
            optionally with (per_sensor_df) when return_per_sensor=True.
        """
        if not self._is_fitted:
            return np.zeros(len(X), dtype=np.float32)

        per_cols: Dict[str, np.ndarray] = {}
        n = len(X)
        if n == 0 or X.shape[1] == 0:
            return (np.zeros(0, dtype=np.float32), pd.DataFrame(index=X.index)) if return_per_sensor else np.zeros(0, dtype=np.float32)

        for c in X.columns:
            series = X[c].to_numpy(copy=False, dtype=np.float32)
            # trained params or sensible defaults
            ph, mu = self.phimap.get(c, (0.0, float(np.nanmean(series))))
            if not np.isfinite(mu):
                mu = 0.0
            sd_train = self.sdmap.get(c, self._sd_floor)
            if not np.isfinite(sd_train) or sd_train <= self._sd_floor:
                sd_train = self._sd_floor

            # Impute only for prediction path; keep original NaNs in residuals
            series_finite = series.copy()
            # fast impute NaNs to mu for lagging/prediction
            if np.isnan(series_finite).any():
                series_finite = np.where(np.isfinite(series_finite), series_finite, mu).astype(np.float32, copy=False)

            # one-step AR(1) prediction with warm start at mu
            pred = np.empty_like(series_finite, dtype=np.float32)
            pred[0] = mu
            if n > 1:
                pred[1:] = (series_finite[:-1] - mu) * ph + mu

            resid = series - pred  # keep NaNs where original series had NaNs
            # normalize using TRAIN residual std
            z = np.abs(resid) / sd_train
            per_cols[c] = z.astype(np.float32, copy=False)

        if not per_cols:
            return (np.zeros(n, dtype=np.float32), pd.DataFrame(index=X.index)) if return_per_sensor else np.zeros(n, dtype=np.float32)

        Z = pd.DataFrame(per_cols, index=X.index)
        # fuse strategy
        if self._fuse == "median":
            fused = Z.median(axis=1, skipna=True).to_numpy(dtype=np.float32)
        elif self._fuse == "p95":
            fused = Z.quantile(0.95, axis=1, interpolation="nearest").to_numpy(dtype=np.float32)
        else:
            fused = Z.mean(axis=1, skipna=True).to_numpy(dtype=np.float32)

        if return_per_sensor:
            return fused, Z
        return fused

    # ---- tiny helpers for persistence (optional) ----
    def to_dict(self) -> Dict[str, Any]:
        return {"phimap": self.phimap, "sdmap": self.sdmap, "cfg": self.cfg}

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "AR1Detector":
        inst = cls(payload.get("cfg"))
        inst.phimap = dict(payload.get("phimap", {}))
        inst.sdmap = dict(payload.get("sdmap", {}))
        inst._is_fitted = True
        return inst


# ------------------------------------------------
# Reporting hook: run(ctx)
# ------------------------------------------------
def _to_datetime_mixed(s):
    try:
        return pd.to_datetime(s, format="mixed", errors="coerce")
    except TypeError:
        return pd.to_datetime(s, errors="coerce")

def _read_scores(p: Path) -> pd.DataFrame:
    df = pd.read_csv(p, dtype={"timestamp": "string"})
    timestamps = _to_datetime_mixed(df["timestamp"])
    try:
        tz_info = getattr(timestamps.dt, "tz", None)
    except AttributeError:
        tz_info = None
    if tz_info is not None:
        try:
            timestamps = timestamps.dt.tz_convert(None)
        except (TypeError, AttributeError):
            timestamps = timestamps.dt.tz_localize(None)
    df["timestamp"] = timestamps
    df = df.set_index("timestamp")
    if getattr(df.index, "tz", None) is not None:
        try:
            df.index = df.index.tz_convert(None)
        except (TypeError, AttributeError):
            df.index = df.index.tz_localize(None)
    df = df[~df.index.isna()]
    # ensure monotonic, drop duplicates (keep last)
    df = df[~df.index.duplicated(keep="last")].sort_index()
    # guard against junk/future dates that blow up ns range
    lo = pd.Timestamp("1970-01-01")
    hi = pd.Timestamp.now() + pd.Timedelta(days=1)
    return df[(df.index >= lo) & (df.index <= hi)]

def _safe_freq(idx: pd.DatetimeIndex, config: Dict[str, Any]) -> Tuple[str, str]:
    """
    Infer frequency with fallback chain and source tracking.
    
    Returns:
        Tuple[str, str]: (frequency, source) where source is "config_override", "inferred", or "config_default"
    """
    # Fallback 1: config override
    if "freq_override" in config:
        return str(config["freq_override"]).replace("T", "min"), "config_override"
    
    # Fallback 2: infer from data
    if len(idx) >= 2:
        inferred = pd.infer_freq(idx)
        if inferred is not None:
            return str(inferred).replace("T", "min"), "inferred"
        # fallback to diff - calculate from actual timestamps
        delta = idx[1] - idx[0]
        total_seconds = delta.total_seconds()
        if total_seconds >= 86400:
            return f"{int(total_seconds/86400)}D", "inferred"
        elif total_seconds >= 3600:
            return f"{int(total_seconds/3600)}H", "inferred"
        elif total_seconds >= 60:
            return f"{int(total_seconds/60)}min", "inferred"
        else:
            return f"{int(total_seconds)}s", "inferred"
    
    # Fallback 3: config default or hardcoded
    default_freq = config.get("default_freq", "1min")
    return str(default_freq).replace("T", "min"), "config_default"

def _safe_forecast_index(last_ts: pd.Timestamp, freq: str, horizon: int) -> pd.DatetimeIndex:
    if getattr(last_ts, "tzinfo", None) is not None:
        try:
            last_ts = last_ts.tz_convert(None)
        except (TypeError, AttributeError):
            last_ts = last_ts.tz_localize(None)
    step = pd.tseries.frequencies.to_offset(freq) # type: ignore
    start = last_ts + step
    # clamp horizon so we don't exceed pandas ns limits
    max_ts = pd.Timestamp.max
    while horizon > 1 and start + (horizon - 1) * step > max_ts:
        horizon //= 2
    return pd.date_range(start=start, periods=horizon, freq=freq)

def _select_best_series(df: pd.DataFrame, config: Dict[str, Any], candidates: list[str]) -> Tuple[Optional[pd.Series], Dict[str, Any]]:
    """
    Intelligently select the best series for forecasting based on stability scoring.
    
    Scoring criteria:
    1. NaN rate (lower is better)
    2. Variance (finite > 0 required)
    3. Data coverage (more points better)
    
    Args:
        df: DataFrame with candidate series
        config: Configuration dict (may contain series_override)
        candidates: List of column names to consider in order of preference
        
    Returns:
        Tuple of (selected series or None, scoring metrics dict)
    """
    # Check for config override
    override = config.get("series_override")
    if override and override in df.columns:
        y = df[override].astype(float).dropna()
        if len(y) >= 20:
            nan_rate = float(df[override].isna().sum() / len(df))
            variance = float(y.var()) if hasattr(y.var(), '__float__') else 0.0
            return y, {"series_used": override, "nan_rate": nan_rate, "variance": variance, "n_points": len(y), "selection_method": "config_override"}
    
    # Score all candidates
    scores_list = []
    for c in candidates:
        if c not in df.columns:
            continue
        series = df[c].astype(float)
        y_clean = series.dropna()
        
        if len(y_clean) < 20:
            continue
            
        nan_rate = float(series.isna().sum() / len(df))
        var_val = y_clean.var()
        variance = float(var_val) if np.isfinite(var_val) else 0.0
        
        if variance <= 0:
            continue
        
        # Scoring: lower NaN rate is better, higher variance (within reason) shows signal
        # Normalize score: lower is better
        score = nan_rate + (1.0 / (1.0 + variance))  # penalize both high NaN and low variance
        
        scores_list.append({
            "series": c,
            "score": score,
            "nan_rate": nan_rate,
            "variance": variance,
            "n_points": len(y_clean)
        })
    
    if not scores_list:
        return None, {}
    
    # Select best (lowest score)
    best = min(scores_list, key=lambda x: x["score"])
    y = df[best["series"]].astype(float).dropna()
    
    return y, {
        "series_used": best["series"],
        "nan_rate": best["nan_rate"],
        "variance": best["variance"],
        "n_points": best["n_points"],
        "selection_method": "stability_scoring"
    }

def run(ctx: Dict[str, Any]):
    """
    Enhanced forecast module with intelligent series selection, dynamic horizon,
    uncertainty bands, robust frequency inference, and optional plotting.
    """
    run_dir = ctx.get("run_dir", Path("."))
    plots_dir = ctx.get("plots_dir", run_dir / "plots")
    tables_dir = ctx.get("tables_dir", run_dir / "tables")
    config = ctx.get("config", {}).get("forecast", {})
    enable_report = ctx.get("enable_report", True)
    
    p = run_dir / "scores.csv"
    if not p.exists():
        return {"module":"forecast","tables":[],"plots":[],"metrics":{},
                "error":{"type":"MissingFile","message":"scores.csv not found"}}

    df = _read_scores(p)

    # FCST-01: Intelligent series selection
    # CHART-01 FIX: Force "fused" series to avoid forecast divergence
    # The fused series is the weighted ensemble of all detectors and provides the most stable forecast
    # Previous issue: gmm_z won stability scoring despite high divergence (34.8%)
    # Override candidates to force fused series selection for reliable forecasts
    config_override = config.copy() if config else {}
    config_override["series_override"] = "fused"
    candidates = ["fused", "cusum_z", "pca_spe_z", "ar1_z", "iforest_z", "gmm_z", "mhal_z"]
    y, selection_metrics = _select_best_series(df, config_override, candidates)
    
    if y is None or len(y) < 20:
        return {"module":"forecast","tables":[],"plots":[],"metrics":{},
                "error":{"type":"NoSeries","message":"No suitable series to forecast"}}

    # Ensure the series has a name for phimap/sdmap keys
    if y.name is None:
        y.name = "target"
    series_name = str(y.name)

    # --- Use AR1Detector for forecasting ---
    ar1_detector = AR1Detector().fit(y.to_frame())
    ph, mu = ar1_detector.phimap.get(series_name, (0.0, float(np.nanmean(y))))
    if not np.isfinite(mu): mu = 0.0
    sd_train = ar1_detector.sdmap.get(series_name, 1.0)
    if not np.isfinite(sd_train) or sd_train <= 1e-9: sd_train = 1.0

    # FCST-04: Robust frequency inference
    y_idx = pd.DatetimeIndex(y.index) if not isinstance(y.index, pd.DatetimeIndex) else y.index
    freq, freq_source = _safe_freq(y_idx, config)
    
    # FCST-02: Dynamic horizon calculation
    horizon_hours = float(config.get("horizon_hours", 24.0))
    # Parse frequency to get time per sample - handle various frequency formats robustly
    try:
        # Try to parse offset directly
        if freq.endswith("min"):
            minutes = float(freq.replace("min", ""))
            sample_duration_seconds = minutes * 60
        elif freq.endswith("s"):
            sample_duration_seconds = float(freq.replace("s", ""))
        elif freq.endswith("h") or freq.endswith("H"):
            hours = float(freq.replace("h", "").replace("H", ""))
            sample_duration_seconds = hours * 3600
        elif freq.endswith("d") or freq.endswith("D"):
            days = float(freq.replace("d", "").replace("D", ""))
            sample_duration_seconds = days * 86400
        else:
            # Fallback: try using pandas offset
            freq_offset = pd.tseries.frequencies.to_offset(freq) # type: ignore
            sample_duration_seconds = freq_offset.nanos / 1e9
        
        samples_per_hour = 3600.0 / sample_duration_seconds if sample_duration_seconds > 0 else 60.0
    except Exception as e:
        Console.warn(f"[FORECAST] Failed to parse frequency '{freq}': {e}, using 1min default")
        samples_per_hour = 60.0  # fallback: 1 minute cadence
    horizon = max(1, int(np.ceil(horizon_hours * samples_per_hour)))
    
    # FCST-03: Confidence intervals
    confidence_k = float(config.get("confidence_k", 1.96))  # 95% CI default
    
    # Generate forecast with uncertainty
    last_val = y.iloc[-1] if not y.empty else mu
    
    try:
        idx_fore = _safe_forecast_index(y.index[-1], freq, horizon)
    except Exception:
        freq, horizon = "1min", min(horizon, 12)
        freq_source = "fallback_emergency"
        idx_fore = _safe_forecast_index(y.index[-1], freq, horizon)

    # FCST-06: Vectorized AR(1) forecast - closed form solution
    # Formula: y_{t+h} = μ + φ^h(y_t - μ)
    # This is 2-5x faster than iterative loop for long horizons
    h_values = np.arange(1, len(idx_fore) + 1)  # h = 1, 2, 3, ..., horizon
    phi_powers = np.power(ph, h_values)  # φ^1, φ^2, φ^3, ..., φ^horizon
    yhat_values = mu + phi_powers * (last_val - mu)  # vectorized computation
    
    yhat = pd.Series(yhat_values, index=idx_fore, name="forecast")
    ci_lower = yhat - confidence_k * sd_train
    ci_upper = yhat + confidence_k * sd_train
    
    # FCST-07: Export forecast metrics CSV
    tables = []
    forecast_confidence_df = pd.DataFrame({
        "timestamp": idx_fore,
        "forecast": yhat.values,
        "ci_lower": ci_lower.values,
        "ci_upper": ci_upper.values
    })
    fc_path = tables_dir / "forecast_confidence.csv"
    forecast_confidence_df.to_csv(fc_path, index=False)
    tables.append({"name": "forecast_confidence", "path": str(fc_path)})
    
    # Metrics export
    metrics_df = pd.DataFrame([{
        "ar1_phi": ph,
        "ar1_mu": mu,
        "ar1_sigma": sd_train,
        "horizon": len(idx_fore),
        "horizon_hours": horizon_hours,
        "freq": freq,
        "freq_source": freq_source,
        "confidence_k": confidence_k,
        **selection_metrics
    }])
    fm_path = tables_dir / "forecast_metrics.csv"
    metrics_df.to_csv(fm_path, index=False)
    tables.append({"name": "forecast_metrics", "path": str(fm_path)})
    
    # CHART-01: Add forecast_diagnostics.csv for troubleshooting
    # Calculate divergence between last observed value and first forecast
    divergence_abs = float(abs(yhat.iloc[0] - last_val)) if len(yhat) > 0 else 0.0
    divergence_pct = float(abs(divergence_abs / (abs(last_val) + 1e-9)) * 100)
    
    # Calculate forecast drift (difference between first and last forecast points)
    forecast_drift = float(abs(yhat.iloc[-1] - yhat.iloc[0])) if len(yhat) > 1 else 0.0
    
    # Recommendation based on diagnostics
    recommendation = "OK"
    if divergence_pct > 50:
        recommendation = "CRITICAL: Divergence > 50% - Consider switching forecast series or detrending"
    elif divergence_pct > 20:
        recommendation = "WARNING: Divergence > 20% - Monitor for forecast accuracy"
    elif abs(ph) > 0.95:
        recommendation = "WARNING: High persistence (phi > 0.95) - Forecast may not revert to mean"
    
    diagnostics_df = pd.DataFrame([{
        "series_name": series_name,
        "ar1_phi": ph,
        "ar1_mu": mu,
        "ar1_sigma": sd_train,
        "last_observed": last_val,
        "first_forecast": yhat.iloc[0] if len(yhat) > 0 else np.nan,
        "divergence_abs": divergence_abs,
        "divergence_pct": divergence_pct,
        "forecast_drift": forecast_drift,
        "ci_width": 2 * confidence_k * sd_train,
        "recommendation": recommendation,
        "selection_method": selection_metrics.get("selection_method", "unknown"),
        "nan_rate": selection_metrics.get("nan_rate", 0.0),
        "variance": selection_metrics.get("variance", 0.0)
    }])
    
    fd_path = tables_dir / "forecast_diagnostics.csv"
    diagnostics_df.to_csv(fd_path, index=False)
    tables.append({"name": "forecast_diagnostics", "path": str(fd_path)})

    # FCST-05: Optional plotting
    plots = []
    if enable_report:
        fig = plt.figure(figsize=(12,4)); ax = plt.gca()
        y.plot(ax=ax, linewidth=1, label="Actual", color="steelblue")
        yhat.plot(ax=ax, linewidth=1.2, linestyle="--", label=f"AR(1) Forecast (+{len(yhat)})", color="darkorange")
        # FCST-03: Plot confidence intervals
        ax.fill_between(idx_fore, ci_lower, ci_upper, alpha=0.2, color="darkorange", label=f"{int(confidence_k*100/1.96)}% CI")
        ax.legend(loc="best")
        ax.set_title(f"Forecast on {series_name} (φ={ph:.3f}, μ={mu:.2f}, σ={sd_train:.3f})")
        ax.set_xlabel("")
        ax.grid(True, alpha=0.3)
        outp = plots_dir / "forecast_overlay.png"
        fig.savefig(outp, dpi=144, bbox_inches="tight"); plt.close(fig)
        plots.append({"title":"Forecast overlay","path":str(outp), 
                     "caption":f"{series_name} — AR(1) forecast with {int(confidence_k*100/1.96)}% confidence bands"})

    metrics = {
        "ar1_phi": ph,
        "ar1_mu": mu,
        "ar1_sigma": sd_train,
        "horizon": int(len(yhat)),
        "horizon_hours": horizon_hours,
        "freq": freq,
        "freq_source": freq_source,
        "confidence_k": confidence_k,
        **selection_metrics
    }
    
    return {"module":"forecast", "tables":tables, "plots":plots, "metrics":metrics}

