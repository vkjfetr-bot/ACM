"""
ACM Run Metadata Writer

Writes comprehensive run-level metadata to ACM_Runs table for:
- Run tracking and auditing
- Performance monitoring
- Quality assessment
- Refit scheduling

Called at the end of every ACM run (success or failure).
"""

from datetime import datetime, timezone
from typing import Optional
import pandas as pd
from utils.logger import Console


def write_run_metadata(
    sql_client,
    run_id: str,
    equip_id: int,
    equip_name: str,
    started_at: datetime,
    completed_at: datetime,
    config_signature: str,
    train_row_count: int,
    score_row_count: int,
    episode_count: int,
    health_status: str,
    avg_health_index: float,
    min_health_index: float,
    max_fused_z: float,
    data_quality_score: float,
    refit_requested: bool,
    kept_columns: str,
    error_message: Optional[str] = None
) -> bool:
    """
    Write run metadata to ACM_Runs table.
    
    Args:
        sql_client: SQL connection client
        run_id: Unique run identifier (UUID)
        equip_id: Equipment ID
        equip_name: Equipment name
        started_at: Run start timestamp (UTC)
        completed_at: Run completion timestamp (UTC)
        config_signature: MD5 hash of config for change detection
        train_row_count: Number of training rows processed
        score_row_count: Number of scoring rows processed
        episode_count: Number of anomaly episodes detected
        health_status: Overall health status (HEALTHY, CAUTION, ALERT)
        avg_health_index: Average health index (0-100)
        min_health_index: Minimum health index (0-100)
        max_fused_z: Maximum fused z-score
        data_quality_score: Data quality metric (0-100)
        refit_requested: Whether model refit was requested
        kept_columns: Comma-separated list of sensor columns used
        error_message: Error message if run failed (optional)
    
    Returns:
        bool: True if write succeeded, False otherwise
    """
    
    if sql_client is None:
        Console.warn("[RUN_META] No SQL client provided, skipping ACM_Runs write")
        return False
    
    try:
        # Calculate duration
        duration_seconds = int((completed_at - started_at).total_seconds())
        
        # Ensure timestamps are UTC naive (SQL datetime2 requirement)
        if started_at.tzinfo is not None:
            started_at = started_at.replace(tzinfo=None)
        if completed_at.tzinfo is not None:
            completed_at = completed_at.replace(tzinfo=None)
        
        # Build insert statement
        insert_sql = """
        INSERT INTO dbo.ACM_Runs (
            RunID, EquipID, EquipName, StartedAt, CompletedAt, DurationSeconds,
            ConfigSignature, TrainRowCount, ScoreRowCount, EpisodeCount,
            HealthStatus, AvgHealthIndex, MinHealthIndex, MaxFusedZ,
            DataQualityScore, RefitRequested, KeptColumns, ErrorMessage, CreatedAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        # Prepare record
        record = (
            run_id,
            equip_id,
            equip_name,
            started_at,
            completed_at,
            duration_seconds,
            config_signature,
            train_row_count,
            score_row_count,
            episode_count,
            health_status,
            float(avg_health_index) if avg_health_index is not None else None,
            float(min_health_index) if min_health_index is not None else None,
            float(max_fused_z) if max_fused_z is not None else None,
            float(data_quality_score) if data_quality_score is not None else None,
            refit_requested,
            kept_columns,
            error_message,
            datetime.now(timezone.utc).replace(tzinfo=None)
        )
        
        # Execute insert
        with sql_client.cursor() as cur:
            cur.execute(insert_sql, record)
        
        # Commit
        sql_client.conn.commit()
        
        Console.info(f"[RUN_META] Wrote run metadata to ACM_Runs: {run_id}")
        return True
        
    except Exception as e:
        Console.error(f"[RUN_META] Failed to write ACM_Runs: {e}")
        try:
            sql_client.conn.rollback()
        except:
            pass
        return False


def compute_run_health_status(avg_health: float, min_health: float) -> str:
    """
    Determine overall run health status based on health metrics.
    
    Args:
        avg_health: Average health index (0-100)
        min_health: Minimum health index (0-100)
    
    Returns:
        str: "HEALTHY", "CAUTION", or "ALERT"
    """
    # Alert if minimum health is critically low
    if min_health < 50:
        return "ALERT"
    
    # Alert if average health is low
    if avg_health < 70:
        return "ALERT"
    
    # Caution if minimum health is borderline
    if min_health < 70:
        return "CAUTION"
    
    # Caution if average health is moderate
    if avg_health < 90:
        return "CAUTION"
    
    # Healthy
    return "HEALTHY"


def extract_run_metadata_from_scores(scores: pd.DataFrame, per_regime_enabled: bool = False, regime_count: int = 0) -> dict:
    """
    Extract health and quality metrics from scores dataframe.
    
    Args:
        scores: Scores dataframe with fused z-scores and precomputed health
        per_regime_enabled: Whether per-regime calibration was enabled (DET-07)
        regime_count: Number of regimes detected
    
    Returns:
        dict: Metadata including health metrics and calibration info
    """
    metadata = {}
    
    try:
        # Use precomputed health if available
        if "__health" in scores.columns:
            health = scores["__health"]
        else:
            # Fallback to computing from fused
            health = 100.0 / (1.0 + scores["fused"] ** 2)
        
        metadata["avg_health_index"] = float(health.mean())
        metadata["min_health_index"] = float(health.min())
        metadata["max_fused_z"] = float(scores["fused"].abs().max())
        
        # Health status
        metadata["health_status"] = compute_run_health_status(
            metadata["avg_health_index"],
            metadata["min_health_index"]
        )
        
        # DET-07: Add per-regime calibration info
        metadata["per_regime_enabled"] = per_regime_enabled
        metadata["regime_count"] = regime_count
        
    except Exception as e:
        Console.warn(f"[RUN_META] Failed to extract health metrics: {e}")
        metadata["avg_health_index"] = None
        metadata["min_health_index"] = None
        metadata["max_fused_z"] = None
        metadata["health_status"] = "UNKNOWN"
        metadata["per_regime_enabled"] = False
        metadata["regime_count"] = 0
    
    return metadata


def extract_data_quality_score(data_quality_path=None, sql_client=None, run_id=None, equip_id=None) -> float:
    """
    Extract overall data quality score from data_quality.csv or ACM_DataQuality SQL table.
    
    OM-CSV-03: Updated to support SQL mode - queries ACM_DataQuality if sql_client provided,
    falls back to CSV if data_quality_path exists.
    
    RM-COR-01: Validates expected schema columns and logs missing fields
    to help diagnose schema drift or incomplete data quality metrics.
    
    Args:
        data_quality_path: Path to data_quality.csv file (file mode)
        sql_client: SQL client for database queries (SQL mode)
        run_id: RunID to query from SQL (SQL mode)
        equip_id: EquipID to query from SQL (SQL mode)
    
    Returns:
        float: Quality score (0-100), or 100.0 if no data found
    """
    try:
        import pandas as pd
        from pathlib import Path
        
        # OM-CSV-03: SQL mode - query ACM_DataQuality
        if sql_client and run_id:
            try:
                query = """
                    SELECT sensor, train_null_pct, score_null_pct
                    FROM dbo.ACM_DataQuality
                    WHERE RunID = ? AND EquipID = ? AND CheckName = 'data_quality'
                """
                with sql_client.cursor() as cur:
                    cur.execute(query, (run_id, int(equip_id or 0)))
                    rows = cur.fetchall()
                
                if rows:
                    df = pd.DataFrame(rows, columns=["sensor", "train_null_pct", "score_null_pct"])
                    # Average null rate across train and score
                    avg_null_pct = (df["train_null_pct"].mean() + df["score_null_pct"].mean()) / 2.0
                    quality_score = 100.0 * (1.0 - avg_null_pct / 100.0)
                    Console.debug(f"[RUN_META] Data quality from SQL: avg_null={avg_null_pct:.2f}%, score={quality_score:.1f}")
                    return float(quality_score)
                else:
                    Console.debug("[RUN_META] No data quality records found in SQL, defaulting to 100.0")
                    return 100.0
            except Exception as e:
                Console.warn(f"[RUN_META] Failed to query ACM_DataQuality: {e}, falling back to CSV")
        
        # File mode: read from CSV
        if data_quality_path and Path(data_quality_path).exists():
            df = pd.read_csv(data_quality_path)
            
            # RM-COR-01: Schema validation - check for expected columns
            expected_columns = {"sensor_name", "null_rate", "constant_rate", "outlier_rate"}
            actual_columns = set(df.columns)
            missing_columns = expected_columns - actual_columns
            
            if missing_columns:
                Console.warn(
                    f"[RUN_META] Data quality schema incomplete: missing columns {sorted(missing_columns)}. "
                    f"Quality score coverage may be reduced."
                )
            
            # Calculate quality score based on null rates
            if "null_rate" in df.columns:
                # 100 - (average null rate across sensors)
                avg_null_rate = df["null_rate"].mean()
                quality_score = 100.0 * (1.0 - avg_null_rate / 100.0)
                
                # Log additional quality metrics if available
                if "constant_rate" in df.columns and "outlier_rate" in df.columns:
                    avg_constant = df["constant_rate"].mean()
                    avg_outlier = df["outlier_rate"].mean()
                    Console.debug(
                        f"[RUN_META] Data quality metrics: null={avg_null_rate:.2f}%, "
                        f"constant={avg_constant:.2f}%, outlier={avg_outlier:.2f}%"
                    )
                
                return float(quality_score)
            else:
                Console.warn(
                    "[RUN_META] Missing 'null_rate' column in data_quality.csv. "
                    "Defaulting to quality score 100.0 (optimistic fallback)."
                )
                return 100.0
        
    except Exception as e:
        Console.warn(f"[RUN_META] Failed to extract data quality score: {e}")
        return 100.0


def write_retrain_metadata(
    sql_client,
    run_id: str,
    equip_id: int,
    equip_name: str,
    retrain_decision: bool,
    retrain_reason: str,
    forecast_state_version: int,
    model_age_batches: Optional[int] = None,
    forecast_rmse: Optional[float] = None,
    forecast_mae: Optional[float] = None,
    forecast_mape: Optional[float] = None,
) -> bool:
    """
    Write forecasting retrain decision + model age + quality metrics to ACM_RunMetadata.

    Args:
        sql_client: Active SQL client (must expose cursor()/conn)
        run_id: Current run unique identifier (UUID string)
        equip_id: Equipment numeric ID
        equip_name: Equipment code/name
        retrain_decision: Whether retraining occurred/is requested this batch
        retrain_reason: Reason string from should_retrain()
        forecast_state_version: Incrementing state version after merge
        model_age_batches: Batches since last retrain (optional if not tracked yet)
        forecast_rmse: Backtest RMSE (optional placeholder)
        forecast_mae: Backtest MAE (optional placeholder)
        forecast_mape: Backtest MAPE (optional placeholder)

    Returns:
        bool: True if insert succeeded.
    """
    if sql_client is None:
        Console.warn("[RUN_META] No SQL client; skipping ACM_RunMetadata write")
        return False

    try:
        insert_sql = """
        INSERT INTO dbo.ACM_RunMetadata (
            RunID, EquipID, EquipName, CreatedAt,
            RetrainDecision, RetrainReason, ForecastStateVersion,
            ModelAgeBatches, ForecastRMSE, ForecastMAE, ForecastMAPE
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        created_at = datetime.utcnow().replace(tzinfo=None)
        record = (
            run_id,
            int(equip_id),
            equip_name,
            created_at,
            bool(retrain_decision),
            retrain_reason[:250] if retrain_reason else None,
            int(forecast_state_version) if forecast_state_version is not None else None,
            int(model_age_batches) if model_age_batches is not None else None,
            float(forecast_rmse) if forecast_rmse is not None else None,
            float(forecast_mae) if forecast_mae is not None else None,
            float(forecast_mape) if forecast_mape is not None else None,
        )

        with sql_client.cursor() as cur:
            cur.execute(insert_sql, record)
        sql_client.conn.commit()
        Console.info(f"[RUN_META] Wrote retrain metadata RunID={run_id} StateV={forecast_state_version}")
        return True
    except Exception as e:
        Console.error(f"[RUN_META] Failed to write ACM_RunMetadata: {e}")
        try:
            sql_client.conn.rollback()
        except Exception:
            pass
        return False
